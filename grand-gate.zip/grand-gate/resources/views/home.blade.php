@extends('app')
@section('content')
    <header class="main-header" role="banner">
        <nav class="navbar navbar-dark fixed-top-custom navbar-expand-lg border-bottom">
            <div class="container">
                <a
                    class="navbar-brand"
                    href="{{asset('home')}}">
                    <img src="{{asset('assets/images/logo.png')}}" alt="key automation" width="175px">
                </a>
                <button
                    class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbar-content"
                    aria-controls="navbar-content"
                    aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="navbar-collapse collapse" id="navbar-content">
                    <ul class="nav navbar-nav">
                        <li class="nav-item dropdown has-megamenu">
                            <a href="" class="nav-link dropdown-toggle"
                               data-bs-toggle="dropdown"
                               role="button"
                               id="subdropdown2"
                               aria-haspopup="true"
                               aria-expanded="false"
                            >GrandGate<span class="caret"></span></a>
                            <div class="dropdown-menu megamenu border-bottom"
                                 role="menu" data-bs-popper="none">
                                <div class="row g-3 w-100">
                                    <div class="offset-md-1 col-md-2 white-border text-white">
                                        <div class="col-megamenu first-level">
                                            <h6 class="title fw-bold text-uppercase">KeyWorld</h6>
                                            <ul class="list-unstyled">
                                                <li>
                                                    <a                                                                     id="link0"
                                                                                                                           class="dropdown-toggle"
                                                                                                                           role="button"
                                                                                                                           data-bs-toggle="dropdown"
                                                                                                                           aria-expanded="false"
                                                    >
                                                        Company
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link0">
                                                        <li>
                                                            <a href="https://keyautomation.com/en/storia"
                                                            >Story</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/azienda"
                                                            >Headquarter</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/ricerca-e-sviluppo"
                                                            >Organization</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/quality-policy"
                                                            >Quality Policy</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                     id="link1"
                                                                                                                           class="dropdown-toggle"
                                                                                                                           role="button"
                                                                                                                           data-bs-toggle="dropdown"
                                                                                                                           aria-expanded="false"
                                                    >
                                                        Technology
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link1">
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/night-light"
                                                            >Night Light System</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/interfacce-per-smartphone"
                                                            >Smartphone interfaces</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/Illuminazione-per-aree-esterne"
                                                            >Lighting for outdoor areas</a>
                                                        </li>
                                                        <li>
                                                            <a href="https://keyautomation.com/en/pages/design"
                                                            >Design</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/news"
                                                    >
                                                        News
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link2">
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/lavora-con-noi"
                                                    >
                                                        Work with us
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link3">
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-1 -->
                                    <div id="boxlink0"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li><a href="https://keyautomation.com/en/storia"
                                                    >Story</a>
                                                </li>
                                                <li><a href="https://keyautomation.com/en/pages/azienda"
                                                    >Headquarter</a>
                                                </li>
                                                <li><a href="https://keyautomation.com/en/pages/ricerca-e-sviluppo"
                                                    >Organization</a>
                                                </li>
                                                <li><a href="https://keyautomation.com/en/pages/quality-policy"
                                                    >Quality Policy</a>
                                                </li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink1"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li><a href="https://keyautomation.com/en/pages/night-light"
                                                    >Night Light System</a>
                                                </li>
                                                <li><a href="https://keyautomation.com/en/pages/interfacce-per-smartphone"
                                                    >Smartphone interfaces</a>
                                                </li>
                                                <li><a href="https://keyautomation.com/en/pages/Illuminazione-per-aree-esterne"
                                                    >Lighting for outdoor areas</a>
                                                </li>
                                                <li><a href="https://keyautomation.com/en/pages/design"
                                                    >Design</a>
                                                </li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink2"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink3"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                </div><!-- end row -->
                            </div> <!-- dropdown-mega-menu.// -->
                        </li>

                        <li class="nav-item dropdown has-megamenu">
                            <a
                                href="https://keyautomation.com/en/products"
                                class="nav-link dropdown-toggle"
                                data-bs-toggle="dropdown"
                                role="button"
                                aria-haspopup="true"
                                aria-expanded="false"
                                id="product_menu">
                                المنتجات
                            </a>
                            <div
                                class="dropdown-menu megamenu border-bottom"
                                role="menu"
                                data-bs-popper="none">
                                <div class="row g-3 w-100">
                                    <div class="offset-md-1 col-md-2 white-border text-white">
                                        <div class="col-megamenu first-level">
                                            <h6 class="title fw-bold text-uppercase">
                                                Product Categories
                                            </h6>
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a                                    id="linkGATEfirst"
                                                                                          data-bs-toggle="dropdown"
                                                                                          class="dropdown-toggle"
                                                                                          role="button"
                                                                                          aria-expanded="false">
                                                        Gates and road barriers
                                                    </a>

                                                    <ul
                                                        class="dropdown-menu"
                                                        aria-labelledby="linkGATE">
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/gate/battenti">
                                                                Systems for swing gates
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkGATEBATTENTIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkBATTENTI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/swing">
                                                                        Linear motors
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGATEBATTENTISWINGthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSWING">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/swing/ray25">
                                                                                RAY Up to 3 m or max 500 kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/swing/ray40">
                                                                                RAY Up to 4 m or max 600 kg
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkGATEBATTENTISWINGRAY40fourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkRAY40">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/swing/ray40/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/swing/ray40/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/swing/ps200">
                                                                                STAR up to 3 m or max 300 kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/swing/ps300">
                                                                                STAR up to 3 m or max 500 kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/swing/ps400">
                                                                                STAR up to 5 m or max 600 kg
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkGATEBATTENTISWINGPS400fourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkPS400">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/swing/ps400/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/swing/ps400/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/arm">
                                                                        Articulated arms
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGATEBATTENTIARMthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkARM">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/arm/revo">
                                                                                RÉVO+ up to 2,3 m
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/arm/mewa">
                                                                                MEWA up to 4 m
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkGATEBATTENTIARMMEWAfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkMEWA">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/arm/mewa/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/arm/mewa/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/under">
                                                                        Underground motors
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkUNDER">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/battenti/under/int">
                                                                                UNDER up to 3,5 m
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkGATEBATTENTIUNDERINTfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkINT">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/under/int/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/battenti/under/int/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/gate/scorrevoli">
                                                                Systems for sliding gates
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkGATESCORREVOLIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkSCORREVOLI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide">
                                                                        Sliding gates
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGATESCORREVOLISLIDEthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSLIDE">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/sun50">
                                                                                SUN up to 400 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/sun80">
                                                                                SUN up to 700 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/sun120">
                                                                                SUN up to 1100 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo30">
                                                                                TURBO up to 400 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo50">
                                                                                TURBO up to 500 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo80">
                                                                                TURBO up to 800 Kg
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkGATESCORREVOLISLIDETURBO80fourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkTURBO80">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo80/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo80/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo160">
                                                                                TURBO up to 1600 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo250">
                                                                                TURBO up to 2500 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo400">
                                                                                TURBO up to 4000 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/gate/barriere">
                                                                Road barriers
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkGATEBARRIEREsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkBARRIERE">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/barriere/bar">
                                                                        Road barriers
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGATEBARRIEREBARthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkBAR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/barriere/bar/alt3k">
                                                                                Barrier with bar from 2.4 to 3 m
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/barriere/bar/alt4k">
                                                                                Barrier with bar from 3 to 5 m
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/barriere/bar/alt6k">
                                                                                Barrier with bar from 4,5 to 8,4 m
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/barriere/bar/ast">
                                                                                Aluminium bar
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/gate/accessori">
                                                                Accessories
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkGATEACCESSORIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkACCESSORI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/accessori/swing">
                                                                        Linear motors
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSWING">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/swing/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/accessori/arm">
                                                                        Articulated arms
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkARM">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/arm/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/accessori/under">
                                                                        Underground motors
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGATEACCESSORIUNDERthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkUNDER">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/under/box">
                                                                                Underground housing box
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/under/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/accessori/slide">
                                                                        Sliding gates
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGATEACCESSORISLIDEthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSLIDE">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/slide/crem">
                                                                                Rack
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/slide/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/gate/accessori/bar">
                                                                        Road barriers
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkBAR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/gate/accessori/bar/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                    </ul>
                                                    <!-- / second level -->
                                                </li>
                                                <li class="">
                                                    <a                                    id="linkDOORfirst"
                                                                                          data-bs-toggle="dropdown"
                                                                                          class="dropdown-toggle"
                                                                                          role="button"
                                                                                          aria-expanded="false">
                                                        Sectional and overhead doors
                                                    </a>

                                                    <ul
                                                        class="dropdown-menu"
                                                        aria-labelledby="linkDOOR">
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/door/garage">
                                                                Systems for sectional and overhead doors
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkDOORGARAGEsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkGARAGE">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/door/garage/section">
                                                                        Sectional doors
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkDOORGARAGESECTIONthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSECTION">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/garage/section/ha8">
                                                                                HALO up to 12 Sqm
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/garage/section/ha12">
                                                                                HALO up to 19 Sqm
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/door/garage/overhead">
                                                                        Overhead doors
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkOVERHEAD">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/garage/overhead/blindo">
                                                                                BLINDO up To 9 sqm
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkDOORGARAGEOVERHEADBLINDOfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkBLINDO">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/door/garage/overhead/blindo/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/door/garage/overhead/blindo/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/door/serrande">
                                                                Systems for rolling shutters
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkDOORSERRANDEsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkSERRANDE">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/door/serrande/rolling">
                                                                        Rolling shutters
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkDOORSERRANDEROLLINGthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkROLLING">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/serrande/rolling/60mm">
                                                                                For Ø 60 mm shaft up to 320 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/serrande/rolling/76mm">
                                                                                For Ø 76 mm shaft up to 350 Kg
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/door/accessori">
                                                                Accessories
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkDOORACCESSORIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkACCESSORI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/door/accessori/section">
                                                                        Sectional doors
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkDOORACCESSORISECTIONthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSECTION">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/accessori/section/rail">
                                                                                Rail
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkDOORACCESSORISECTIONRAILfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkRAIL">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/door/accessori/section/rail/1x3b"
                                                                                    >3-Pieces rail, 3100 mm
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/door/accessori/section/rail/3mb"
                                                                                    >1-Piece rail, 3100 mm
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/door/accessori/section/rail/4mb"
                                                                                    >1-Piece rail, 4100 mm
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/accessori/section/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/door/accessori/overhead">
                                                                        Overhead doors
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkOVERHEAD">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/accessori/overhead/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/door/accessori/rolling">
                                                                        Rolling shutters
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkROLLING">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/door/accessori/rolling/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                    </ul>
                                                    <!-- / second level -->
                                                </li>
                                                <li class="">
                                                    <a                                    id="linkAUTODOORfirst"
                                                                                          data-bs-toggle="dropdown"
                                                                                          class="dropdown-toggle"
                                                                                          role="button"
                                                                                          aria-expanded="false">
                                                        Pedestrian doors
                                                    </a>

                                                    <ul
                                                        class="dropdown-menu"
                                                        aria-labelledby="linkAUTODOOR">
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/autodoor/porteautomatiche">
                                                                Pedestrian doors
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkAUTODOORPORTEAUTOMATICHEsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkPORTEAUTOMATICHE">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided">
                                                                        Sliding Doors
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSLIDED">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete">
                                                                                Complete automation
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETEfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkCOMPLETE">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/1leaf"
                                                                                    >Sliding doors with 1 leaf
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/1leaft"
                                                                                    >Sliding telescopic door with 1+1 leaf
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/2leaf"
                                                                                    >Sliding doors with 2 leaves
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/2leaft"
                                                                                    >Sliding telescopic door with 2+2 leaves
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/kit">
                                                                                Automation kit
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkAUTODOORPORTEAUTOMATICHESLIDEDKITfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkKIT">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/kit/1leaft"
                                                                                    >Sliding telescopic door with 1+1 leaf
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/kit/2leaft"
                                                                                    >Sliding telescopic door with 2+2 leaves
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/accessor">
                                                                        Accessories
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkACCESSOR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/autodoor/porteautomatiche/accessor/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/autodoor/accessori">
                                                                Accessories
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkAUTODOORACCESSORIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkACCESSORI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/autodoor/accessori/keypad">
                                                                        Keypads and selectors
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkKEYPAD">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/autodoor/accessori/keypad/sel">
                                                                                Key and digital switches
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/autodoor/accessori/accessor">
                                                                        Accessories
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkAUTODOORACCESSORIACCESSORthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkACCESSOR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/autodoor/accessori/accessor/radar">
                                                                                Radar and photocells
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/autodoor/accessori/accessor/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                    </ul>
                                                    <!-- / second level -->
                                                </li>
                                                <li class="">
                                                    <a                                    id="linkGARDENfirst"
                                                                                          data-bs-toggle="dropdown"
                                                                                          class="dropdown-toggle"
                                                                                          role="button"
                                                                                          aria-expanded="false">
                                                        Outdoor led lighting
                                                    </a>

                                                    <ul
                                                        class="dropdown-menu"
                                                        aria-labelledby="linkGARDEN">
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/garden/garden">
                                                                Outdoor led lighting
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkGARDENGARDENsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkGARDEN">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/garden/garden/lamp">
                                                                        Outdoor lights
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGARDENGARDENLAMPthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkLAMP">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/stiksd">
                                                                                STIK S DOWN LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/stiksu">
                                                                                STIK S UP LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/flat">
                                                                                FLAT LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/tonda">
                                                                                TONDA Recessed LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/vertical">
                                                                                VERTICAL LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/stikm">
                                                                                STIK M LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/tower">
                                                                                TOWER LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/garden/lamp/stella">
                                                                                STELLA LED garden light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/garden/accessori">
                                                                Accessories
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkGARDENACCESSORIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkACCESSORI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/garden/accessori/control">
                                                                        Control units
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkCONTROL">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/accessori/control/boxled">
                                                                                Led lights control
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/garden/accessori/accessor">
                                                                        Accessories
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkGARDENACCESSORIACCESSORthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkACCESSOR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/accessori/accessor/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/garden/accessori/accessor/quadro">
                                                                                Night light sensor
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                    </ul>
                                                    <!-- / second level -->
                                                </li>
                                                <li class="">
                                                    <a                                    id="linkACCESSORfirst"
                                                                                          data-bs-toggle="dropdown"
                                                                                          class="dropdown-toggle"
                                                                                          role="button"
                                                                                          aria-expanded="false">
                                                        Accessories
                                                    </a>

                                                    <ul
                                                        class="dropdown-menu"
                                                        aria-labelledby="linkACCESSOR">
                                                        <li class="nav-item">
                                                            <a
                                                                href="https://keyautomation.com/en/products/accessor/accessori">
                                                                Accessories
                                                            </a>
                                                            <!-- carret -->

                                                            <a
                                                                id="linkACCESSORACCESSORIsecond"
                                                                data-bs-toggle="dropdown"
                                                                class="dropdown-toggle ms-1"
                                                                role="button"
                                                                aria-expanded="false">
                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                            </a>

                                                            <ul
                                                                class="dropdown-menu"
                                                                aria-labelledby="linkACCESSORI">
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/iot">
                                                                        IoT
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkIoT">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/iot/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/control">
                                                                        Control units
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORICONTROLthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkCONTROL">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/14a">
                                                                                14A Control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/ct10224">
                                                                                CT10224 control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/ct20224">
                                                                                CT20224 control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/ct102">
                                                                                CT102 control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/ct202">
                                                                                CT202 dontrol unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/ct1e">
                                                                                CT1RS control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/control/ct400">
                                                                                CT400 control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/tx">
                                                                        Transmitters
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORITXthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkTX">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/tx/sub">
                                                                                Water resistant 4 channels transmitter
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/tx/play">
                                                                                4 Channels transmitter in ABS
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/tx/touch">
                                                                                1/2 Channels touch transmitter
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/photo">
                                                                        Photocells
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORIPHOTOthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkPHOTO">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/photo/ft20">
                                                                                Photocells for small pillars
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/photo/ft30">
                                                                                Photocells for flush mounting
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/photo/ft40">
                                                                                Photocells adjustable through 180°
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/photo/post">
                                                                                Posts for photocells
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/rx">
                                                                        Receivers
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORIRXthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkRX">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/rx/rx2h">
                                                                                Miniaturized receiver
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/rx/rx4">
                                                                                Plug-In receiver
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/rx/rxm">
                                                                                Universal receivers
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/flash">
                                                                        Flashing lights
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORIFLASHthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkFLASH">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/flash/eclipse">
                                                                                Full led flashing light
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/flash/lumy">
                                                                                Flashing light
                                                                            </a>
                                                                            <!-- carret -->
                                                                            <a
                                                                                id="linkACCESSORACCESSORIFLASHLUMYfourth"
                                                                                data-bs-toggle="dropdown"
                                                                                class="dropdown-toggle ms-1"
                                                                                role="button"
                                                                                aria-expanded="false">
                                                                                <i class="fas fa-2x fa-caret-down"></i>
                                                                            </a>

                                                                            <ul
                                                                                class="dropdown-menu"
                                                                                aria-labelledby="linkLUMY">
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/flash/lumy/230v"
                                                                                    >230V
                                                                                    </a>
                                                                                </li>
                                                                                <li class="nav-item">
                                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/flash/lumy/24v"
                                                                                    >24V
                                                                                    </a>
                                                                                </li>
                                                                            </ul>
                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/edge">
                                                                        Safety Edges
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkEDGE">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/edge/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/keypad">
                                                                        Keypads and selectors
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORIKEYPADthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkKEYPAD">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/keypad/ego">
                                                                                Key and digital switches EGO
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/keypad/sel">
                                                                                Key and digital switches
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/solar">
                                                                        Solar
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkSOLAR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/solar/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/accessor">
                                                                        Accessories
                                                                    </a>
                                                                    <!-- carret -->
                                                                    <a
                                                                        id="linkACCESSORACCESSORIACCESSORthird"
                                                                        data-bs-toggle="dropdown"
                                                                        class="dropdown-toggle ms-1"
                                                                        role="button"
                                                                        aria-expanded="false">
                                                                        <i class="fas fa-2x fa-caret-down"></i>
                                                                    </a>

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkACCESSOR">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/accessor/14a">
                                                                                14A Control unit
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/accessor/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a href="https://keyautomation.com/en/products/accessor/accessori/battery">
                                                                        Batteries
                                                                    </a>
                                                                    <!-- carret -->

                                                                    <ul
                                                                        class="dropdown-menu"
                                                                        aria-labelledby="linkBATTERY">
                                                                        <li class="nav-item">
                                                                            <a href="https://keyautomation.com/en/products/accessor/accessori/battery/other">
                                                                                Accessories
                                                                            </a>
                                                                            <!-- carret -->

                                                                            <!-- / fifth level -->
                                                                        </li>
                                                                    </ul>
                                                                    <!-- / fourth level -->
                                                                </li>
                                                            </ul>
                                                            <!-- /third level -->
                                                        </li>
                                                    </ul>
                                                    <!-- / second level -->
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div id="boxlinkGATEfirst"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIsecond"
                                                        href="https://keyautomation.com/en/products/gate/battenti"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Systems for swing gates</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLIsecond"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Systems for sliding gates</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBARRIEREsecond"
                                                        href="https://keyautomation.com/en/products/gate/barriere"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Road barriers</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIsecond"
                                                        href="https://keyautomation.com/en/products/gate/accessori"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORfirst"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGEsecond"
                                                        href="https://keyautomation.com/en/products/door/garage"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Systems for sectional and overhead doors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORSERRANDEsecond"
                                                        href="https://keyautomation.com/en/products/door/serrande"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Systems for rolling shutters</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORIsecond"
                                                        href="https://keyautomation.com/en/products/door/accessori"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORfirst"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHEsecond"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Pedestrian doors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORACCESSORIsecond"
                                                        href="https://keyautomation.com/en/products/autodoor/accessori"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGARDENfirst"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENsecond"
                                                        href="https://keyautomation.com/en/products/garden/garden"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Outdoor led lighting</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENACCESSORIsecond"
                                                        href="https://keyautomation.com/en/products/garden/accessori"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORfirst"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIsecond"
                                                        href="https://keyautomation.com/en/products/accessor/accessori"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEACCESSORIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORISWINGthird"
                                                        href="https://keyautomation.com/en/products/gate/accessori/swing"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Linear motors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIARMthird"
                                                        href="https://keyautomation.com/en/products/gate/accessori/arm"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Articulated arms</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIUNDERthird"
                                                        href="https://keyautomation.com/en/products/gate/accessori/under"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Underground motors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORISLIDEthird"
                                                        href="https://keyautomation.com/en/products/gate/accessori/slide"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding gates</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIBARthird"
                                                        href="https://keyautomation.com/en/products/gate/accessori/bar"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Road barriers</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBARRIEREsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBARRIEREBARthird"
                                                        href="https://keyautomation.com/en/products/gate/barriere/bar"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Road barriers</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGthird"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Linear motors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIARMthird"
                                                        href="https://keyautomation.com/en/products/gate/battenti/arm"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Articulated arms</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIUNDERthird"
                                                        href="https://keyautomation.com/en/products/gate/battenti/under"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Underground motors</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATESCORREVOLIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDEthird"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding gates</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORACCESSORIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORISECTIONthird"
                                                        href="https://keyautomation.com/en/products/door/accessori/section"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sectional doors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORIOVERHEADthird"
                                                        href="https://keyautomation.com/en/products/door/accessori/overhead"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Overhead doors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORIROLLINGthird"
                                                        href="https://keyautomation.com/en/products/door/accessori/rolling"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Rolling shutters</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORGARAGEsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGESECTIONthird"
                                                        href="https://keyautomation.com/en/products/door/garage/section"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sectional doors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGEOVERHEADthird"
                                                        href="https://keyautomation.com/en/products/door/garage/overhead"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Overhead doors</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORSERRANDEsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORSERRANDEROLLINGthird"
                                                        href="https://keyautomation.com/en/products/door/serrande/rolling"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Rolling shutters</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORACCESSORIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORACCESSORIKEYPADthird"
                                                        href="https://keyautomation.com/en/products/autodoor/accessori/keypad"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Keypads and selectors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORACCESSORIACCESSORthird"
                                                        href="https://keyautomation.com/en/products/autodoor/accessori/accessor"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORPORTEAUTOMATICHEsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDthird"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding Doors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHEACCESSORthird"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/accessor"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGARDENACCESSORIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGARDENACCESSORICONTROLthird"
                                                        href="https://keyautomation.com/en/products/garden/accessori/control"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Control units</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENACCESSORIACCESSORthird"
                                                        href="https://keyautomation.com/en/products/garden/accessori/accessor"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGARDENGARDENsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPthird"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Outdoor lights</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIsecond"
                                         class="col-md-2 third-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIIoTthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/iot"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >IoT</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Control units</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORITXthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/tx"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Transmitters</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIPHOTOthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/photo"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Photocells</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIRXthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/rx"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Receivers</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIFLASHthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/flash"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Flashing lights</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIEDGEthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/edge"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Safety Edges</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIKEYPADthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/keypad"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Keypads and selectors</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORISOLARthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/solar"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Solar</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIACCESSORthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/accessor"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIBATTERYthird"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/battery"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Batteries</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEACCESSORIARMthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIARMOTHERfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/arm/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEACCESSORIBARthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIBAROTHERfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/bar/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEACCESSORISLIDEthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORISLIDECREMfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/slide/crem"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Rack</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORISLIDEOTHERfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/slide/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEACCESSORISWINGthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORISWINGOTHERfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/swing/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEACCESSORIUNDERthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIUNDERBOXfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/under/box"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Underground housing box</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEACCESSORIUNDEROTHERfourth"
                                                        href="https://keyautomation.com/en/products/gate/accessori/under/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBARRIEREBARthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBARRIEREBARALT3Kfourth"
                                                        href="https://keyautomation.com/en/products/gate/barriere/bar/alt3k"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Barrier with bar from 2.4 to 3 m</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBARRIEREBARALT4Kfourth"
                                                        href="https://keyautomation.com/en/products/gate/barriere/bar/alt4k"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Barrier with bar from 3 to 5 m</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBARRIEREBARALT6Kfourth"
                                                        href="https://keyautomation.com/en/products/gate/barriere/bar/alt6k"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Barrier with bar from 4,5 to 8,4 m</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBARRIEREBARASTfourth"
                                                        href="https://keyautomation.com/en/products/gate/barriere/bar/ast"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Aluminium bar</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTIARMthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIARMREVOfourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/arm/revo"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >RÉVO+ up to 2,3 m</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIARMMEWAfourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/arm/mewa"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >MEWA up to 4 m</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTISWINGthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGRAY25fourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ray25"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >RAY Up to 3 m or max 500 kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGRAY40fourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ray40"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >RAY Up to 4 m or max 600 kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGPS200fourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ps200"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STAR up to 3 m or max 300 kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGPS300fourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ps300"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STAR up to 3 m or max 500 kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGPS400fourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ps400"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STAR up to 5 m or max 600 kg</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTIUNDERthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIUNDERINTfourth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/under/int"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >UNDER up to 3,5 m</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATESCORREVOLISLIDEthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDESUN50fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/sun50"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >SUN up to 400 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDESUN80fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/sun80"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >SUN up to 700 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDESUN120fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/sun120"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >SUN up to 1100 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO30fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo30"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TURBO up to 400 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO50fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo50"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TURBO up to 500 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO80fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo80"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TURBO up to 800 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO160fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo160"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TURBO up to 1600 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO250fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo250"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TURBO up to 2500 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO400fourth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo400"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TURBO up to 4000 Kg</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORACCESSORIOVERHEADthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORIOVERHEADOTHERfourth"
                                                        href="https://keyautomation.com/en/products/door/accessori/overhead/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORACCESSORIROLLINGthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORIROLLINGOTHERfourth"
                                                        href="https://keyautomation.com/en/products/door/accessori/rolling/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORACCESSORISECTIONthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORISECTIONRAILfourth"
                                                        href="https://keyautomation.com/en/products/door/accessori/section/rail"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Rail</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORISECTIONOTHERfourth"
                                                        href="https://keyautomation.com/en/products/door/accessori/section/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORGARAGEOVERHEADthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGEOVERHEADBLINDOfourth"
                                                        href="https://keyautomation.com/en/products/door/garage/overhead/blindo"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >BLINDO up To 9 sqm</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORGARAGESECTIONthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGESECTIONHA8fourth"
                                                        href="https://keyautomation.com/en/products/door/garage/section/ha8"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >HALO up to 12 Sqm</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGESECTIONHA12fourth"
                                                        href="https://keyautomation.com/en/products/door/garage/section/ha12"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >HALO up to 19 Sqm</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORSERRANDEROLLINGthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORSERRANDEROLLING60MMfourth"
                                                        href="https://keyautomation.com/en/products/door/serrande/rolling/60mm"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >For Ø 60 mm shaft up to 320 Kg</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORSERRANDEROLLING76MMfourth"
                                                        href="https://keyautomation.com/en/products/door/serrande/rolling/76mm"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >For Ø 76 mm shaft up to 350 Kg</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORACCESSORIACCESSORthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORACCESSORIACCESSORRADARfourth"
                                                        href="https://keyautomation.com/en/products/autodoor/accessori/accessor/radar"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Radar and photocells</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORACCESSORIACCESSOROTHERfourth"
                                                        href="https://keyautomation.com/en/products/autodoor/accessori/accessor/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORACCESSORIKEYPADthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORACCESSORIKEYPADSELfourth"
                                                        href="https://keyautomation.com/en/products/autodoor/accessori/keypad/sel"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Key and digital switches</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORPORTEAUTOMATICHEACCESSORthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHEACCESSOROTHERfourth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/accessor/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORPORTEAUTOMATICHESLIDEDthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETEfourth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Complete automation</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDKITfourth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/kit"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Automation kit</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGARDENACCESSORIACCESSORthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGARDENACCESSORIACCESSOROTHERfourth"
                                                        href="https://keyautomation.com/en/products/garden/accessori/accessor/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENACCESSORIACCESSORQUADROfourth"
                                                        href="https://keyautomation.com/en/products/garden/accessori/accessor/quadro"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Night light sensor</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGARDENACCESSORICONTROLthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGARDENACCESSORICONTROLBOXLEDfourth"
                                                        href="https://keyautomation.com/en/products/garden/accessori/control/boxled"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Led lights control</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGARDENGARDENLAMPthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPSTIKSDfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/stiksd"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STIK S DOWN LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPSTIKSUfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/stiksu"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STIK S UP LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPFLATfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/flat"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >FLAT LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPTONDAfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/tonda"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TONDA Recessed LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPVERTICALfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/vertical"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >VERTICAL LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPSTIKMfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/stikm"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STIK M LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPTOWERfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/tower"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >TOWER LED garden light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGARDENGARDENLAMPSTELLAfourth"
                                                        href="https://keyautomation.com/en/products/garden/garden/lamp/stella"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >STELLA LED garden light</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIACCESSORthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIACCESSOR14Afourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/accessor/14a"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >14A Control unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIACCESSOROTHERfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/accessor/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIBATTERYthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIBATTERYOTHERfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/battery/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORICONTROLthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROL14Afourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/14a"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >14A Control unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLCT10224fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/ct10224"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >CT10224 control unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLCT20224fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/ct20224"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >CT20224 control unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLCT102fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/ct102"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >CT102 control unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLCT202fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/ct202"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >CT202 dontrol unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLCT1Efourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/ct1e"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >CT1RS control unit</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORICONTROLCT400fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/control/ct400"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >CT400 control unit</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIEDGEthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIEDGEOTHERfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/edge/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIFLASHthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIFLASHECLIPSEfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/flash/eclipse"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Full led flashing light</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIFLASHLUMYfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/flash/lumy"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Flashing light</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIIoTthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIIoTOTHERfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/iot/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIKEYPADthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIKEYPADEGOfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/keypad/ego"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Key and digital switches EGO</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIKEYPADSELfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/keypad/sel"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Key and digital switches</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIPHOTOthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIPHOTOFT20fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/photo/ft20"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Photocells for small pillars</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIPHOTOFT30fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/photo/ft30"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Photocells for flush mounting</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIPHOTOFT40fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/photo/ft40"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Photocells adjustable through 180°</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIPHOTOPOSTfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/photo/post"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Posts for photocells</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIRXthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIRXRX2Hfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/rx/rx2h"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Miniaturized receiver</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIRXRX4fourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/rx/rx4"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Plug-In receiver</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIRXRXMfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/rx/rxm"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Universal receivers</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORISOLARthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORISOLAROTHERfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/solar/other"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Accessories</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORITXthird"
                                         class="col-md-2 fourth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORITXSUBfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/tx/sub"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Water resistant 4 channels transmitter</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORITXPLAYfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/tx/play"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >4 Channels transmitter in ABS</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORITXTOUCHfourth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/tx/touch"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >1/2 Channels touch transmitter</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTIARMMEWAfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIARMMEWA24Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/arm/mewa/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIARMMEWA230Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/arm/mewa/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTISWINGPS400fourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGPS40024Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ps400/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGPS400230Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ps400/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTISWINGRAY40fourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGRAY4024Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ray40/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTISWINGRAY40230Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/swing/ray40/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATEBATTENTIUNDERINTfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIUNDERINT24Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/under/int/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATEBATTENTIUNDERINT230Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/battenti/under/int/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkGATESCORREVOLISLIDETURBO80fourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO8024Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo80/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkGATESCORREVOLISLIDETURBO80230Vfifth"
                                                        href="https://keyautomation.com/en/products/gate/scorrevoli/slide/turbo80/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORACCESSORISECTIONRAILfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORISECTIONRAIL1X3Bfifth"
                                                        href="https://keyautomation.com/en/products/door/accessori/section/rail/1x3b"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >3-Pieces rail, 3100 mm</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORISECTIONRAIL3MBfifth"
                                                        href="https://keyautomation.com/en/products/door/accessori/section/rail/3mb"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >1-Piece rail, 3100 mm</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORACCESSORISECTIONRAIL4MBfifth"
                                                        href="https://keyautomation.com/en/products/door/accessori/section/rail/4mb"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >1-Piece rail, 4100 mm</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkDOORGARAGEOVERHEADBLINDOfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGEOVERHEADBLINDO24Vfifth"
                                                        href="https://keyautomation.com/en/products/door/garage/overhead/blindo/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkDOORGARAGEOVERHEADBLINDO230Vfifth"
                                                        href="https://keyautomation.com/en/products/door/garage/overhead/blindo/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETEfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE2LEAFfifth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/2leaf"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding doors with 2 leaves</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE1LEAFfifth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/1leaf"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding doors with 1 leaf</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE2LEAFTfifth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/2leaft"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding telescopic door with 2+2 leaves</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE1LEAFTfifth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/complete/1leaft"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding telescopic door with 1+1 leaf</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkAUTODOORPORTEAUTOMATICHESLIDEDKITfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDKIT2LEAFTfifth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/kit/2leaft"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding telescopic door with 2+2 leaves</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkAUTODOORPORTEAUTOMATICHESLIDEDKIT1LEAFTfifth"
                                                        href="https://keyautomation.com/en/products/autodoor/porteautomatiche/slided/kit/1leaft"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >Sliding telescopic door with 1+1 leaf</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                    <div id="boxlinkACCESSORACCESSORIFLASHLUMYfourth"
                                         class="col-md-2 fifth-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIFLASHLUMY24Vfifth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/flash/lumy/24v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >24V</a></li>
                                                <li class="">
                                                    <a
                                                        id="linkACCESSORACCESSORIFLASHLUMY230Vfifth"
                                                        href="https://keyautomation.com/en/products/accessor/accessori/flash/lumy/230v"
                                                        class="dropdown-toggle-custom"
                                                        role="button"
                                                        aria-expanded="false"
                                                    >230V</a></li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div>
                                </div><!-- end row -->
                            </div> <!-- dropdown-mega-menu.// -->
                        </li>
                        <li class="nav-item dropdown has-megamenu">
                            <a href="" class="nav-link dropdown-toggle"
                               data-bs-toggle="dropdown"
                               role="button"
                               id="subdropdown2"
                               aria-haspopup="true"
                               aria-expanded="false"
                            >سابقة اعمال<span class="caret"></span></a>
                            <div class="dropdown-menu megamenu border-bottom"
                                 role="menu" data-bs-popper="none">
                                <div class="row g-3 w-100">
                                    <div class="offset-md-1 col-md-2 white-border text-white">
                                        <div class="col-megamenu first-level">
                                            <h6 class="title fw-bold text-uppercase">Supporto</h6>
                                            <ul class="list-unstyled">
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/manual"
                                                    >
                                                        Instruction manuals
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link0">
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/area-download"
                                                    >
                                                        Download area
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link1">
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/store-locator"
                                                    >
                                                        Service centers
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link2">
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/pages/support"
                                                    >
                                                        Return Merchandise Authorization
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link3">
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-1 -->
                                    <div id="boxlink0"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink1"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink2"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink3"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                </div><!-- end row -->
                            </div> <!-- dropdown-mega-menu.// -->
                        </li>
                        <li class="nav-item dropdown has-megamenu">
                            <a href="https://keyautomation.com/en/contatti"
                               class="nav-link"
                            >
                                تواصل معنا
                            </a>
                        </li>
                        <li class="nav-item dropdown has-megamenu">
                            <a href="https://keyautomation.com/en/contatti"
                               class="nav-link"
                            >
                                الاخبار
                            </a>
                        </li>
                        <li class="nav-item dropdown has-megamenu">
                            <a href="" class="nav-link dropdown-toggle"
                               data-bs-toggle="dropdown"
                               role="button"
                               id="subdropdown2"
                               aria-haspopup="true"
                               aria-expanded="false"
                            >البوم صور<span class="caret"></span></a>
                            <div class="dropdown-menu megamenu border-bottom"
                                 role="menu" data-bs-popper="none">
                                <div class="row g-3 w-100">
                                    <div class="offset-md-1 col-md-2 white-border text-white">
                                        <div class="col-megamenu first-level">
                                            <h6 class="title fw-bold text-uppercase">Key Partner</h6>
                                            <ul class="list-unstyled">
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/pages/partner"
                                                    >
                                                        Become a Key Partner
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link0">
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a                                                                 href="https://keyautomation.com/en/store-locator"
                                                    >
                                                        Key Partner List
                                                    </a>
                                                    <ul class="dropdown-menu"
                                                        aria-labelledby="link1">
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-1 -->
                                    <div id="boxlink0"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                    <div id="boxlink1"
                                         class="col-md-2 second-level white-border text-white">
                                        <div class="col-megamenu">
                                            <ul class="list-unstyled">
                                            </ul>
                                        </div> <!-- col-megamenu.// -->
                                    </div><!-- end col-3 -->
                                </div><!-- end row -->
                            </div> <!-- dropdown-mega-menu.// -->
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right align-items-sm-center">
{{--                        <li class="dropdown has-megamenu area-personal-menu">--}}
{{--                            <a href="https://keyautomation.com/en/login"--}}
{{--                               class="nav-link text-sm text-gray-700 dark:text-gray-500 underline"--}}
{{--                            >Login</a>--}}
{{--                        </li>--}}
                        <li class="dropdown search">
                            <a
                                id="btn-cerca"
                                class="nav-link dropdown-toggle"
                                data-bs-toggle="dropdown"
                                role="button"
                                aria-haspopup="true"
                                aria-expanded="false">
                                <i class="fas fa-search"></i>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                <li>
                                    <form class="col-12" method="get" action="https://keyautomation.com/en/products">
                                        <input
                                            id="cerca"
                                            type="search"
                                            class="form-control"
                                            placeholder="search...."
                                            aria-label="Search"
                                            name="nav_search"
                                            value="">
                                    </form>
                                </li>
                            </ul>
                        </li>
                       {{-- <li class="dropdown lingue-menu">
                            <a
                                href="#"
                                class="nav-link dropdown-toggle"
                                data-bs-toggle="dropdown"
                                role="button"
                                aria-haspopup="true"
                                aria-expanded="false">
                            <span class="text-uppercase">
                                en
                            </span>
                            </a>
                            <ul
                                class="dropdown-menu default-dropdown-menu"
                                aria-labelledby="dropdownMenuLingue">
                                <li class="">
                                    <a
                                        href="#"
                                        class="dropdown-item "
                                        onclick="location.href ='https://keyautomation.com/it'">
                                        <img
                                            class="image"
                                            src="https://keyautomation.com/icons/it.svg"
                                            alt="0">
                                        <span class="text-capitalize">
                                        Italiano
                                    </span>
                                    </a>
                                </li>
                                <li class="">
                                    <a
                                        href="#"
                                        class="dropdown-item active"
                                        onclick="location.href ='https://keyautomation.com/en'">
                                        <img
                                            class="image"
                                            src="https://keyautomation.com/icons/en.svg"
                                            alt="1">
                                        <span class="text-capitalize">
                                        English
                                    </span>
                                    </a>
                                </li>
                                <li class="">
                                    <a
                                        href="#"
                                        class="dropdown-item "
                                        onclick="location.href ='https://keyautomation.com/es'">
                                        <img
                                            class="image"
                                            src="https://keyautomation.com/icons/es.svg"
                                            alt="2">
                                        <span class="text-capitalize">
                                        Español
                                    </span>
                                    </a>
                                </li>
                                <li class="">
                                    <a
                                        href="#"
                                        class="dropdown-item "
                                        onclick="location.href ='https://keyautomation.com/fr'">
                                        <img
                                            class="image"
                                            src="https://keyautomation.com/icons/fr.svg"
                                            alt="3">
                                        <span class="text-capitalize">
                                        Français
                                    </span>
                                    </a>
                                </li>
                            </ul>
                        </li>--}}
                    </ul>
                </div><!-- /.navbar-collapse -->

            </div><!-- /.container-fluid -->
        </nav>
    </header>
    <!--end header-->
    <main aria-live="polite" aria-atomic="true" class="position-relative">
        <div class="container-fluid p-0" id="home-page">
            <!--carousler-->
            <section class="slider">
                <div id="carouselExampleControls" class="carousel slide slide-container" data-bs-ride="carousel">
                    <div class="carousel-inner">

                        <div class="carousel-item active" data-bs-interval="5000">
                            <img src="{{asset('assets/images/product-showcase/images/ocr (4).jpeg')}}" class="img-fluid w-100"
                                 alt="Home-Page2016087701.jpg">

                        </div>
                        <div class="carousel-item " data-bs-interval="5000">
                            <img src="{{asset('assets/images/product-showcase/images/5df9157ad4087d4dcc15.jpeg')}}" class="img-fluid w-100"
                                 alt="Vista_06486741145.jpg">

                        </div>
                    </div>

                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                            data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                            data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </section>
            <section class="first-banner container-fluid">
                <div class="container">
                    <div class="row py-4">
                        <div class="col-xs-12 col-md-6 offset-md-3 text-center">
                            <h2 class="h6 fw-bold text-uppercase"></h2>
                            <p class="small"><p>Key Automation develops and manufactures automation systems for gates, garage doors, road barriers and pedestrian doors</p></p>
                            <a href="https://keyautomation.com/en/catalogo-online" class="btn btn-dark btn-sm fw-bold text-uppercase rounded-0">DISCOVER OUR NEW CATALOG 2023</a>
                        </div>
                    </div>
                </div>
            </section>
            <div class="container-fluid gamme-prodotti">
                <h4 class="text-center h3 my-4 text-uppercase fw-bold">Products</h4>
                <div class="container product-list mt-4">
                    <div class="row">
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="https://keyautomation.com/en/products/gate">
                                <div class="card rounded-0 border-0">
                                    <img src="{{asset('assets/images/product-category/images/1.jpg')}}"
                                         class="card-img-top rounded-0 h-100"
                                         alt="Scorrevoli-1909867360.jpg"
                                         onerror="this.onerror=null;this.src='https://keyautomation.com/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold">رولر شتر</h6>
                                        <p class="card-text" >ابواب شتر جراند جيت ذات تصميم انيق من أجود الخامات على اعلى مستوى من الامان والحمايه نادرة</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="https://keyautomation.com/en/products/autodoor">
                                <div class="card rounded-0 border-0">
                                    <img src="{{asset('assets/images/product-category/images/2.jpg')}}"
                                         class="card-img-top rounded-0 h-100"
                                         alt="key-industry-51439572906.jpg"
                                         onerror="this.onerror=null;this.src='https://keyautomation.com/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold">بوابات منزلقة ومفصلية اوتوماتيك</h6>
                                        <p class="card-text" >تصميم وتصنيع وتركيب بوابات منزلقه او مفصلية لمداخل المصانع – الفيلات والقصور بمقاسات.</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="https://keyautomation.com/en/products/garden">
                                <div class="card rounded-0 border-0">
                                    <img src="{{asset('assets/images/product-category/images/3.jpg')}}"
                                         class="card-img-top rounded-0 h-100"
                                         alt="GARDEN1344946780.jpg"
                                         style="height: 100%"
                                         onerror="this.onerror=null;this.src='https://keyautomation.com/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold">الابواب الزجاجية المنزلقة</h6>
                                        <p class="card-text" >مداخل البنوك – المولات – غرف العمليات – المحلات الكبري -المباني الادارية وتوكيلات السيارات…</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="https://keyautomation.com/en/products/accessor">
                                <div class="card rounded-0 border-0">
                                    <img src="{{asset('assets/images/product-category/images/4.jpg')}}"
                                         class="card-img-top rounded-0 h-100"
                                         alt="ECLIPDSE405272089.jpg"
                                         style="height: 100%"
                                         onerror="this.onerror=null;this.src='https://keyautomation.com/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold">الحواجز المرورية</h6>
                                        <p class="card-text" >البوابات الأوتوماتيكية الإليكترونية لمداخل السيارات والمباني الإدارية ومداخل المنتجعات السكنية …</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <section class="prodotti-evidenza container-fluid">
                <div class="container text-center py-3">
                    <h3 class="h3 fw-bold text-uppercase text-center mb-4">منتجات مميزة</h3>
                    <!-- Set up your HTML -->
                    <div id="" class="owl-carousel prodotti owl-loaded">
                        <div class="owl-stage-outer">
                            <div class="owl-stage">
                                <a href='https://keyautomation.com/en/products/accessor/accessori/photo/post/other/900eg100la' class="owl-item">
                                    <img class="img-fluid w-100"  src="{{asset('assets/images/product-category/images/1.jpg')}}" alt="COLONNINA725338140.jpg">
                                    <h4 class="slide-title">EGO Column supports</h4>
                                </a>
                                <a href='https://keyautomation.com/en/products/accessor/accessori/tx/sub' class="owl-item">
                                    <img class="img-fluid w-100"  src="{{asset('assets/images/product-category/images/5.jpg')}}" alt="SUB171489545.jpg">
                                    <h4 class="slide-title">4 Channels transmitter SUB</h4>
                                </a>
                                <a href='https://keyautomation.com/en/products/gate/battenti/arm/revo' class="owl-item">
                                    <img class="img-fluid w-100"  src="{{asset('assets/images/product-category/images/3.jpg')}}" alt="REVO725144497.jpg">
                                    <h4 class="slide-title">Gear motor RÉVO+</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
{{--            <section class="instagram container-fluid">--}}
{{--                <div class="container pb-4">--}}
{{--                    <h3 class="h3 fw-bold text-uppercase text-center pt-4 pb-3">Key automation Live</h3>--}}
{{--                    <div class="intafeed-container text-end">--}}
{{--                        <div id="instafeed" class="row"></div>--}}
{{--                        <a class="btn btn-dark py-1 mt-3 fw-bold text-uppercase" target="_blank" href="https://www.instagram.com/keyautomationitaly/">Load more</a>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </section>--}}

            <section class="illuminazione-banner container-fluid">

                <div class="banner-container text-center py-3 ">
                    <h3 class="h3 fw-bold text-uppercase mt-2 mb-4"></h3>
                    <img src="{{asset('assets/images/product-showcase/images/5fbfac36f0df37387e22095e_32x10_large.jpeg')}}" class="img-fluid w-100 image"
                         alt="BANNER-Garden_337371440.jpg">
                    <div class="illuminazione-bottom-banner py-3">
                        <p></p>
                        <a href="https://keyautomation.com/en/pages/Illuminazione-per-aree-esterne" class="btn btn-dark btn-sm fw-bold text-uppercase rounded-0">الجودة عنواننا, تاريخنا وخبرتنا يتحدثون عنا</a>
                    </div>
                </div>

            </section>

{{--            <section class="third-banner container-fluid mb-4">--}}
{{--                <div class="container">--}}
{{--                    <div class="row py-4">--}}
{{--                        <div class="col-xs-12 col-md-6 offset-md-3 text-center">--}}
{{--                            <h2 class="h6 fw-bold text-uppercase"></h2>--}}
{{--                            <p class="small"><p>Discover all the exclusive benefits of the Key Partner programme and become a Key Automation partner installer </p></p>--}}
{{--                            <a href="https://keyautomation.com/en/pages/partn   er" class="btn btn-dark btn-sm fw-bold text-uppercase rounded-0">Join the KEY Team</a>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </section>--}}

            <section class="maps">
                <h3 class="h3 fw-bold text-uppercase text-light text-center bg-secondary py-3 mb-4">أين نحن</h3>
                <div class="map" id="map">
                    <iframe
                        height="450"
                        style="border:0"
                        loading="lazy"
                        allowfullscreen
                        src="https://www.google.com/maps/embed/v1/place?key=AIzaSyClfNx3H1AleMFCzr_DSZA2m9GOXy4v2aI&q=Key%20automation,%20Via%20Antonio%20Meucci,%2023,%2030027%20San%20Don%C3%A0%20di%20Piave%20VE">
                    </iframe>

                </div>
            </section>
{{--            <section class="risorse-utili container-fluid mt-4">--}}
{{--                <div class="container text-center">--}}
{{--                    <h3 class="h3 fw-bold text-uppercase text-center mb-4">Resources</h3>--}}
{{--                    <div class="d-lg-flex">--}}
{{--                        <div class="w-100 card rounded-0">--}}
{{--                            <a href="https://keyautomation.com/en/area-download">--}}
{{--                                <div class="card-body">--}}
{{--                                    <p class="m-0"><strong>Download area</strong></p>--}}
{{--                                    <p class="card-text">Instruction manuals, Catalogues and Installation Modules </p>--}}
{{--                                </div>--}}
{{--                            </a>--}}
{{--                        </div>--}}
{{--                        <div class="w-100 card rounded-0">--}}
{{--                            <a href="https://keyautomation.com/en/store-locator">--}}
{{--                                <div class="card-body">--}}
{{--                                    <p class="m-0"><strong>Customer Service</strong></p>--}}
{{--                                    <p class="card-text">Service Centers and Partner Installers</p>--}}
{{--                                </div>--}}
{{--                            </a>--}}
{{--                        </div>--}}
{{--                        <div class="w-100 card rounded-0">--}}
{{--                            <a href="https://keyautomation.com/en/news">--}}
{{--                                <div class="card-body">--}}
{{--                                    <p class="m-0"><strong>News</strong></p>--}}
{{--                                    <p class="card-text">All the latest Key Automation news</p>--}}
{{--                                </div>--}}
{{--                            </a>--}}
{{--                        </div>--}}
{{--                        <div class="w-100 card rounded-0">--}}
{{--                            <a href="https://keyautomation.com/en/lavora-con-noi">--}}
{{--                                <div class="card-body">--}}
{{--                                    <p class="m-0"><strong>Work with us</strong></p>--}}
{{--                                    <p class="card-text">Join our team</p>--}}
{{--                                </div>--}}
{{--                            </a>--}}
{{--                        </div>--}}
{{--                        <div class="w-100 card rounded-0">--}}
{{--                            <a href="https://keyautomation.com/en/pages/partner">--}}
{{--                                <div class="card-body">--}}
{{--                                    <p class="m-0"><strong>Become a Key Partner</strong></p>--}}
{{--                                    <p class="card-text">Discover all the exclusive benefits of becoming a KEY PARTNER INSTALLER and join the team</p>--}}
{{--                                </div>--}}
{{--                            </a>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </section>--}}

            <br>
            <br>
            <br>


        </div>
    </main>

    <div class="container-fluid" id="footer-container">
        <footer>
            <div class="row bg-dark-blue text-white">
                <div class="col-lg-6 col-12 mb-0 mb-md-4 pb-0 ">
                    <p>Follow us</p>
                    <ul class="list-unstyled social-icon social mb-0 mt-4">
                        <li class="icon">
                            <a href="https://www.facebook.com/pages/KEY-AUTOMATION/227631273939043" target="_blank">
                                <i class="fab fa-facebook"></i></a></li>
                        <li class="icon"><a href="https://www.instagram.com/keyautomationitaly/?feature=watch"
                                            target="_blank"><i class="fab fa-instagram"></i></a></li>
                        <li class="icon"><a href="http://www.youtube.com/user/KEYAUTOMATION?feature=watch"
                                            target="_blank"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-12 mb-0 mb-md-4 pb-0">
                    <ul class="list-unstyled related-links mb-0 mt-4">

                        <li>
                            <a href="https://keyautomation.com/en/pages/privacy">
                                Privacy &amp; Cookies
                            </a>
                        </li>
                        <li>
                            <a href="https://keyautomation.com/en/pages/terms-of-sales">
                                Terms of sales
                            </a>
                        </li>
                        <li>
                            <a href="https://keyautomation.com/en/pages/legal-disclaimer">
                                Legal Disclaimer
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="logo mb-2"><img src="{{asset('assets/images/logo.png')}}" alt="key automation" width="175px"></div>
                <div class="text-center">
                    <p class="text-light"><small>GrandGate S.r.l. - Via Meucci 23, 30027 San Donà di Piave (VE) – Ph. +39 0421 307456 – VAT No. 03627650264 – Share Capital euro 154.000,00 i.v. <br/> Venice Business Register 03627650264 - REA VE 326953 - info@keyautomation.it - www.keyautomation.com</small></p>
                </div>

            </div>
        </footer><!--end footer-->
    </div>

@endsection
