<?php $__env->startSection('content'); ?>
    <!--end header-->

            <section class="first-banner container-fluid">
                <div class="container">
                    <div class="row py-4" style="display: flex;justify-content: center;align-items: center;flex-direction: row;flex-wrap: nowrap;">
                        <div class="col-xs-12 col-md-6 text-center">
                            <h2 class="h6 fw-bold text-uppercase"></h2>
                            <p class="small"><p style="text-align-last: center;">تقوم شركة جراند جيت بتطوير وتصنيع أنظمة التشغيل الآلي للبوابات وأبواب الجراجات وحواجز الطرق وأبواب المشاة</p></p>
                            <a href="/en/catalogo-online" class="btn btn-dark btn-sm fw-bold text-uppercase ">اكتشف الكتالوج الجديد 2023</a>
                        </div>
                    </div>
                </div>
            </section>
            <div class="container-fluid gamme-prodotti">
                <h4 class="text-center h3 my-4 text-uppercase fw-bold">المنتجات</h4>
                <div class="container product-list mt-4">
                    <div class="row">
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="/en/products/gate">
                                <div class="card rounded-0 border-0">
                                    <img src="<?php echo e(asset('assets/images/product-category/images/1.jpg')); ?>"
                                         class="card-img-top rounded-0 h-100"
                                         alt="Scorrevoli-1909867360.jpg"
                                         onerror="this.onerror=null;this.src='/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold" style="text-align: start;">رولر شتر</h6>
                                        <p class="card-text" style="text-align: start;">ابواب شتر جراند جيت ذات تصميم انيق من أجود الخامات على اعلى مستوى من الامان والحمايه نادرة</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="/en/products/autodoor">
                                <div class="card rounded-0 border-0">
                                    <img src="<?php echo e(asset('assets/images/product-category/images/2.jpg')); ?>"
                                         class="card-img-top rounded-0 h-100"
                                         alt="key-industry-51439572906.jpg"
                                         onerror="this.onerror=null;this.src='/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold" style="text-align: start;">بوابات منزلقة ومفصلية اوتوماتيك</h6>
                                        <p class="card-text" style="text-align: start;">تصميم وتصنيع وتركيب بوابات منزلقه او مفصلية لمداخل المصانع – الفيلات والقصور بمقاسات.</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="/en/products/garden">
                                <div class="card rounded-0 border-0">
                                    <img src="<?php echo e(asset('assets/images/product-category/images/3.jpg')); ?>"
                                         class="card-img-top rounded-0 h-100"
                                         alt="GARDEN1344946780.jpg"
                                         style="height: 100%"
                                         onerror="this.onerror=null;this.src='/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold" style="text-align: start;">الابواب الزجاجية المنزلقة</h6>
                                        <p class="card-text" style="text-align: start;">مداخل البنوك – المولات – غرف العمليات – المحلات الكبري -المباني الادارية وتوكيلات السيارات…</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xs-12 col-md-3 my-3">

                            <a href="/en/products/accessor">
                                <div class="card rounded-0 border-0">
                                    <img src="<?php echo e(asset('assets/images/product-category/images/4.jpg')); ?>"
                                         class="card-img-top rounded-0 h-100"
                                         alt="ECLIPDSE405272089.jpg"
                                         style="height: 100%"
                                         onerror="this.onerror=null;this.src='/images/placeholder-image.jpg';"
                                    >
                                    <div class="card-body">
                                        <h6 class="card-title text-uppercase fw-bold" style="text-align: start;">الحواجز المرورية</h6>
                                        <p class="card-text" style="text-align: start;">البوابات الأوتوماتيكية الإليكترونية لمداخل السيارات والمباني الإدارية ومداخل المنتجعات السكنية …</p>
                                        <div class="d-flex justify-content-between">


                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <section class="prodotti-evidenza container-fluid">
                <div class="container text-center py-3">
                    <h3 class="h3 fw-bold text-uppercase text-center mb-4">منتجات مميزة</h3>
                    <!-- Set up your HTML -->
                    <div id="" class="owl-carousel prodotti owl-loaded">
                        <div class="owl-stage-outer">
                            <div class="owl-stage">
                                <a href='/en/products/accessor/accessori/photo/post/other/900eg100la' class="owl-item">
                                    <img class="img-fluid w-100"  src="<?php echo e(asset('assets/images/product-category/images/1.jpg')); ?>" alt="COLONNINA725338140.jpg">
                                    <h4 class="slide-title">EGO Column supports</h4>
                                </a>
                                <a href='/en/products/accessor/accessori/tx/sub' class="owl-item">
                                    <img class="img-fluid w-100"  src="<?php echo e(asset('assets/images/product-category/images/5.jpg')); ?>" alt="SUB171489545.jpg">
                                    <h4 class="slide-title">4 Channels transmitter SUB</h4>
                                </a>
                                <a href='/en/products/gate/battenti/arm/revo' class="owl-item">
                                    <img class="img-fluid w-100"  src="<?php echo e(asset('assets/images/product-category/images/3.jpg')); ?>" alt="REVO725144497.jpg">
                                    <h4 class="slide-title">Gear motor RÉVO+</h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="illuminazione-banner container-fluid">

                <div class="banner-container text-center py-3 ">
                    <h3 class="h3 fw-bold text-uppercase mt-2 mb-4"></h3>
                    <img src="<?php echo e(asset('assets/images/product-showcase/images/5fbfac36f0df37387e22095e_32x10_large.jpeg')); ?>" class="img-fluid w-100 image"
                         alt="BANNER-Garden_337371440.jpg">
                    <div class="illuminazione-bottom-banner py-3" style="display: flex;justify-content: center;align-items: center;align-content: flex-end;flex-wrap: nowrap;flex-direction: row-reverse;">
                        <p></p>
                        <a href="/en/pages/Illuminazione-per-aree-esterne" class="btn btn-dark btn-sm fw-bold text-uppercase rounded-0">الجودة عنواننا, تاريخنا وخبرتنا يتحدثون عنا</a>
                    </div>
                </div>

            </section>

            <section class="maps">
                <h3 class="h3 fw-bold text-uppercase text-light text-center bg-secondary py-3 mb-4">أين نحن</h3>
                <div class="map" id="map">
                    <iframe
                        height="450"
                        style="border:0"
                        allowfullscreen
                        src="https://www.google.com/maps/@29.9723606,31.091353,15z?entry=ttu">
                    </iframe>

                </div>
            </section>
            <br>
            <br>
            <br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hassan/Documents/grand-gate/resources/views/home.blade.php ENDPATH**/ ?>