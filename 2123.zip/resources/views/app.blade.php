<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}"  dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="https://.com/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://.com/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://.com/favicons/favicon-16x16.png">

    <link rel="mask-icon" href="https://.com/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
          integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>

    <link rel="stylesheet" href="{{asset('assets/css/owl.carousel.min.css')}}">
    <!-- Styles -->
    <link href="{{asset('assets/css/app.css')}}" rel="stylesheet">
    <!-- Styles -->
    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="https://.com/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://.com/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://.com/favicons/favicon-16x16.png">

    <link rel="mask-icon" href="https://.com/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
          integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
          crossorigin="anonymous" referrerpolicy="no-referrer"/>

    <link rel="stylesheet" href="https://.com/js/libs/OwlCarousel2/assets/owl.carousel.min.css">
    <!-- Styles -->
    <link href="https://.com/css/frontend/app.css" rel="stylesheet">
    <style>
        *{
            text-align: end;
        }
    </style>
</head>
<body class="antialiased">

<header class="main-header" role="banner">
    <nav class="navbar navbar-dark fixed-top-custom navbar-expand-lg border-bottom">
        <div class="container">
            <a
                class="navbar-brand"
                href="{{route('home')}}">
                <img src="{{asset('assets/images/logo.png')}}" alt="key automation" width="175px">
            </a>
            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbar-content"
                aria-controls="navbar-content"
                aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="navbar-collapse collapse" id="navbar-content">
                <ul class="nav navbar-nav">
                    <li class="nav-item dropdown has-megamenu">
                        <a href="" class="nav-link dropdown-toggle"
                           data-bs-toggle="dropdown"
                           role="button"
                           id="subdropdown2"
                           aria-haspopup="true"
                           aria-expanded="false"
                        >جراند جيت<span class="caret"></span></a>
                        <div class="dropdown-menu megamenu border-bottom"
                             role="menu" data-bs-popper="none">
                            <div class="row g-3 w-100">
                                <div class="offset-md-1 col-md-2 white-border text-white">
                                    <div class="col-megamenu first-level">
                                        <ul class="list-unstyled">
                                            <li>
                                                <a                                                                     id="link0"
                                                                                                                       class="dropdown-toggle"
                                                                                                                       role="button"
                                                                                                                       data-bs-toggle="dropdown"
                                                                                                                       aria-expanded="false"
                                                >
                                                    من نحن
                                                </a>
                                            </li>
                                        </ul>
                                    </div> <!-- col-megamenu.// -->
                                </div><!-- end col-1 -->

                            </div><!-- end row -->
                        </div> <!-- dropdown-mega-menu.// -->
                    </li>

                    <li class="nav-item dropdown has-megamenu">
                        <a
                            href="/en/products"
                            class="nav-link dropdown-toggle"
                            data-bs-toggle="dropdown"
                            role="button"
                            aria-haspopup="true"
                            aria-expanded="false"
                            id="product_menu">
                            المنتجات
                        </a>
                        <div
                            class="dropdown-menu megamenu border-bottom"
                            role="menu"
                            data-bs-popper="none">
                            <div class="row g-3 w-100">
                                <div class="offset-md-1 col-md-2 white-border text-white">
                                    <div class="col-megamenu first-level">

                                        <ul class="list-unstyled">
                                            <li class="">
                                                <a  id="linkGATEfirst"
                                                    class="dropdown-toggle-custom"
                                                    href="{{route('product','رولر شتر')}}"
                                                    role="button">
                                                    رولر شتر
                                                </a>
                                                <!-- / second level -->
                                            </li>
                                            <li class="">
                                                <a id="linkGATEfirst"
                                                   class="dropdown-toggle-custom"
                                                   role="button"
                                                   aria-expanded="false">
                                                    بوابات منزلقة ومفصلية اوتوماتيك
                                                </a>
                                                <!-- / second level -->
                                            </li>
                                            <li class="">
                                                <a id="linkGATEfirst"
                                                   class="dropdown-toggle-custom"
                                                   role="button"
                                                   aria-expanded="false">
                                                    الابواب الزجاجية المنزلقة
                                                </a>
                                                <!-- / second level -->
                                            </li>
                                            <li class="">
                                                <a id="linkGATEfirst"
                                                   class="dropdown-toggle-custom"
                                                   role="button"
                                                   aria-expanded="false">
                                                    حواجز مرورية                                                </a>
                                                <!-- / second level -->
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                {{-- <div id="boxlinkGATEfirst"
                                      class="col-md-2 second-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIsecond"
                                                     href="/en/products/gate/battenti"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Systems for swing gates</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLIsecond"
                                                     href="/en/products/gate/scorrevoli"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Systems for sliding gates</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBARRIEREsecond"
                                                     href="/en/products/gate/barriere"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Road barriers</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIsecond"
                                                     href="/en/products/gate/accessori"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORfirst"
                                      class="col-md-2 second-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGEsecond"
                                                     href="/en/products/door/garage"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Systems for sectional and overhead doors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORSERRANDEsecond"
                                                     href="/en/products/door/serrande"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Systems for rolling shutters</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORIsecond"
                                                     href="/en/products/door/accessori"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORfirst"
                                      class="col-md-2 second-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHEsecond"
                                                     href="/en/products/autodoor/porteautomatiche"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Pedestrian doors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORACCESSORIsecond"
                                                     href="/en/products/autodoor/accessori"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGARDENfirst"
                                      class="col-md-2 second-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENsecond"
                                                     href="/en/products/garden/garden"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Outdoor led lighting</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENACCESSORIsecond"
                                                     href="/en/products/garden/accessori"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORfirst"
                                      class="col-md-2 second-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIsecond"
                                                     href="/en/products/accessor/accessori"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEACCESSORIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORISWINGthird"
                                                     href="/en/products/gate/accessori/swing"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Linear motors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIARMthird"
                                                     href="/en/products/gate/accessori/arm"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Articulated arms</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIUNDERthird"
                                                     href="/en/products/gate/accessori/under"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Underground motors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORISLIDEthird"
                                                     href="/en/products/gate/accessori/slide"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding gates</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIBARthird"
                                                     href="/en/products/gate/accessori/bar"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Road barriers</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBARRIEREsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBARRIEREBARthird"
                                                     href="/en/products/gate/barriere/bar"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Road barriers</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGthird"
                                                     href="/en/products/gate/battenti/swing"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Linear motors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIARMthird"
                                                     href="/en/products/gate/battenti/arm"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Articulated arms</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIUNDERthird"
                                                     href="/en/products/gate/battenti/under"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Underground motors</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATESCORREVOLIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDEthird"
                                                     href="/en/products/gate/scorrevoli/slide"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding gates</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORACCESSORIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORISECTIONthird"
                                                     href="/en/products/door/accessori/section"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sectional doors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORIOVERHEADthird"
                                                     href="/en/products/door/accessori/overhead"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Overhead doors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORIROLLINGthird"
                                                     href="/en/products/door/accessori/rolling"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Rolling shutters</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORGARAGEsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGESECTIONthird"
                                                     href="/en/products/door/garage/section"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sectional doors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGEOVERHEADthird"
                                                     href="/en/products/door/garage/overhead"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Overhead doors</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORSERRANDEsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORSERRANDEROLLINGthird"
                                                     href="/en/products/door/serrande/rolling"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Rolling shutters</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORACCESSORIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORACCESSORIKEYPADthird"
                                                     href="/en/products/autodoor/accessori/keypad"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Keypads and selectors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORACCESSORIACCESSORthird"
                                                     href="/en/products/autodoor/accessori/accessor"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORPORTEAUTOMATICHEsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDthird"
                                                     href="/en/products/autodoor/porteautomatiche/slided"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding Doors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHEACCESSORthird"
                                                     href="/en/products/autodoor/porteautomatiche/accessor"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGARDENACCESSORIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGARDENACCESSORICONTROLthird"
                                                     href="/en/products/garden/accessori/control"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Control units</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENACCESSORIACCESSORthird"
                                                     href="/en/products/garden/accessori/accessor"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGARDENGARDENsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPthird"
                                                     href="/en/products/garden/garden/lamp"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Outdoor lights</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIsecond"
                                      class="col-md-2 third-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIIoTthird"
                                                     href="/en/products/accessor/accessori/iot"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >IoT</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLthird"
                                                     href="/en/products/accessor/accessori/control"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Control units</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORITXthird"
                                                     href="/en/products/accessor/accessori/tx"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Transmitters</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIPHOTOthird"
                                                     href="/en/products/accessor/accessori/photo"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Photocells</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIRXthird"
                                                     href="/en/products/accessor/accessori/rx"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Receivers</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIFLASHthird"
                                                     href="/en/products/accessor/accessori/flash"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Flashing lights</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIEDGEthird"
                                                     href="/en/products/accessor/accessori/edge"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Safety Edges</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIKEYPADthird"
                                                     href="/en/products/accessor/accessori/keypad"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Keypads and selectors</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORISOLARthird"
                                                     href="/en/products/accessor/accessori/solar"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Solar</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIACCESSORthird"
                                                     href="/en/products/accessor/accessori/accessor"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIBATTERYthird"
                                                     href="/en/products/accessor/accessori/battery"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Batteries</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEACCESSORIARMthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIARMOTHERfourth"
                                                     href="/en/products/gate/accessori/arm/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEACCESSORIBARthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIBAROTHERfourth"
                                                     href="/en/products/gate/accessori/bar/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEACCESSORISLIDEthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORISLIDECREMfourth"
                                                     href="/en/products/gate/accessori/slide/crem"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Rack</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORISLIDEOTHERfourth"
                                                     href="/en/products/gate/accessori/slide/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEACCESSORISWINGthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORISWINGOTHERfourth"
                                                     href="/en/products/gate/accessori/swing/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEACCESSORIUNDERthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIUNDERBOXfourth"
                                                     href="/en/products/gate/accessori/under/box"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Underground housing box</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEACCESSORIUNDEROTHERfourth"
                                                     href="/en/products/gate/accessori/under/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBARRIEREBARthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBARRIEREBARALT3Kfourth"
                                                     href="/en/products/gate/barriere/bar/alt3k"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Barrier with bar from 2.4 to 3 m</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBARRIEREBARALT4Kfourth"
                                                     href="/en/products/gate/barriere/bar/alt4k"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Barrier with bar from 3 to 5 m</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBARRIEREBARALT6Kfourth"
                                                     href="/en/products/gate/barriere/bar/alt6k"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Barrier with bar from 4,5 to 8,4 m</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBARRIEREBARASTfourth"
                                                     href="/en/products/gate/barriere/bar/ast"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Aluminium bar</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTIARMthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIARMREVOfourth"
                                                     href="/en/products/gate/battenti/arm/revo"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >RÉVO+ up to 2,3 m</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIARMMEWAfourth"
                                                     href="/en/products/gate/battenti/arm/mewa"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >MEWA up to 4 m</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTISWINGthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGRAY25fourth"
                                                     href="/en/products/gate/battenti/swing/ray25"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >RAY Up to 3 m or max 500 kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGRAY40fourth"
                                                     href="/en/products/gate/battenti/swing/ray40"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >RAY Up to 4 m or max 600 kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGPS200fourth"
                                                     href="/en/products/gate/battenti/swing/ps200"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STAR up to 3 m or max 300 kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGPS300fourth"
                                                     href="/en/products/gate/battenti/swing/ps300"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STAR up to 3 m or max 500 kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGPS400fourth"
                                                     href="/en/products/gate/battenti/swing/ps400"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STAR up to 5 m or max 600 kg</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTIUNDERthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIUNDERINTfourth"
                                                     href="/en/products/gate/battenti/under/int"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >UNDER up to 3,5 m</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATESCORREVOLISLIDEthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDESUN50fourth"
                                                     href="/en/products/gate/scorrevoli/slide/sun50"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >SUN up to 400 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDESUN80fourth"
                                                     href="/en/products/gate/scorrevoli/slide/sun80"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >SUN up to 700 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDESUN120fourth"
                                                     href="/en/products/gate/scorrevoli/slide/sun120"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >SUN up to 1100 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO30fourth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo30"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TURBO up to 400 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO50fourth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo50"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TURBO up to 500 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO80fourth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo80"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TURBO up to 800 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO160fourth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo160"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TURBO up to 1600 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO250fourth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo250"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TURBO up to 2500 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO400fourth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo400"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TURBO up to 4000 Kg</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORACCESSORIOVERHEADthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORIOVERHEADOTHERfourth"
                                                     href="/en/products/door/accessori/overhead/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORACCESSORIROLLINGthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORIROLLINGOTHERfourth"
                                                     href="/en/products/door/accessori/rolling/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORACCESSORISECTIONthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORISECTIONRAILfourth"
                                                     href="/en/products/door/accessori/section/rail"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Rail</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORISECTIONOTHERfourth"
                                                     href="/en/products/door/accessori/section/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORGARAGEOVERHEADthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGEOVERHEADBLINDOfourth"
                                                     href="/en/products/door/garage/overhead/blindo"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >BLINDO up To 9 sqm</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORGARAGESECTIONthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGESECTIONHA8fourth"
                                                     href="/en/products/door/garage/section/ha8"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >HALO up to 12 Sqm</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGESECTIONHA12fourth"
                                                     href="/en/products/door/garage/section/ha12"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >HALO up to 19 Sqm</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORSERRANDEROLLINGthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORSERRANDEROLLING60MMfourth"
                                                     href="/en/products/door/serrande/rolling/60mm"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >For Ø 60 mm shaft up to 320 Kg</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORSERRANDEROLLING76MMfourth"
                                                     href="/en/products/door/serrande/rolling/76mm"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >For Ø 76 mm shaft up to 350 Kg</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORACCESSORIACCESSORthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORACCESSORIACCESSORRADARfourth"
                                                     href="/en/products/autodoor/accessori/accessor/radar"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Radar and photocells</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORACCESSORIACCESSOROTHERfourth"
                                                     href="/en/products/autodoor/accessori/accessor/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORACCESSORIKEYPADthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORACCESSORIKEYPADSELfourth"
                                                     href="/en/products/autodoor/accessori/keypad/sel"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Key and digital switches</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORPORTEAUTOMATICHEACCESSORthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHEACCESSOROTHERfourth"
                                                     href="/en/products/autodoor/porteautomatiche/accessor/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORPORTEAUTOMATICHESLIDEDthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETEfourth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/complete"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Complete automation</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDKITfourth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/kit"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Automation kit</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGARDENACCESSORIACCESSORthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGARDENACCESSORIACCESSOROTHERfourth"
                                                     href="/en/products/garden/accessori/accessor/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENACCESSORIACCESSORQUADROfourth"
                                                     href="/en/products/garden/accessori/accessor/quadro"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Night light sensor</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGARDENACCESSORICONTROLthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGARDENACCESSORICONTROLBOXLEDfourth"
                                                     href="/en/products/garden/accessori/control/boxled"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Led lights control</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGARDENGARDENLAMPthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPSTIKSDfourth"
                                                     href="/en/products/garden/garden/lamp/stiksd"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STIK S DOWN LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPSTIKSUfourth"
                                                     href="/en/products/garden/garden/lamp/stiksu"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STIK S UP LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPFLATfourth"
                                                     href="/en/products/garden/garden/lamp/flat"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >FLAT LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPTONDAfourth"
                                                     href="/en/products/garden/garden/lamp/tonda"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TONDA Recessed LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPVERTICALfourth"
                                                     href="/en/products/garden/garden/lamp/vertical"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >VERTICAL LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPSTIKMfourth"
                                                     href="/en/products/garden/garden/lamp/stikm"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STIK M LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPTOWERfourth"
                                                     href="/en/products/garden/garden/lamp/tower"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >TOWER LED garden light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGARDENGARDENLAMPSTELLAfourth"
                                                     href="/en/products/garden/garden/lamp/stella"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >STELLA LED garden light</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIACCESSORthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIACCESSOR14Afourth"
                                                     href="/en/products/accessor/accessori/accessor/14a"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >14A Control unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIACCESSOROTHERfourth"
                                                     href="/en/products/accessor/accessori/accessor/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIBATTERYthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIBATTERYOTHERfourth"
                                                     href="/en/products/accessor/accessori/battery/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORICONTROLthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROL14Afourth"
                                                     href="/en/products/accessor/accessori/control/14a"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >14A Control unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLCT10224fourth"
                                                     href="/en/products/accessor/accessori/control/ct10224"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >CT10224 control unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLCT20224fourth"
                                                     href="/en/products/accessor/accessori/control/ct20224"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >CT20224 control unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLCT102fourth"
                                                     href="/en/products/accessor/accessori/control/ct102"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >CT102 control unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLCT202fourth"
                                                     href="/en/products/accessor/accessori/control/ct202"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >CT202 dontrol unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLCT1Efourth"
                                                     href="/en/products/accessor/accessori/control/ct1e"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >CT1RS control unit</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORICONTROLCT400fourth"
                                                     href="/en/products/accessor/accessori/control/ct400"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >CT400 control unit</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIEDGEthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIEDGEOTHERfourth"
                                                     href="/en/products/accessor/accessori/edge/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIFLASHthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIFLASHECLIPSEfourth"
                                                     href="/en/products/accessor/accessori/flash/eclipse"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Full led flashing light</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIFLASHLUMYfourth"
                                                     href="/en/products/accessor/accessori/flash/lumy"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Flashing light</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIIoTthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIIoTOTHERfourth"
                                                     href="/en/products/accessor/accessori/iot/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIKEYPADthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIKEYPADEGOfourth"
                                                     href="/en/products/accessor/accessori/keypad/ego"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Key and digital switches EGO</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIKEYPADSELfourth"
                                                     href="/en/products/accessor/accessori/keypad/sel"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Key and digital switches</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIPHOTOthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIPHOTOFT20fourth"
                                                     href="/en/products/accessor/accessori/photo/ft20"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Photocells for small pillars</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIPHOTOFT30fourth"
                                                     href="/en/products/accessor/accessori/photo/ft30"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Photocells for flush mounting</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIPHOTOFT40fourth"
                                                     href="/en/products/accessor/accessori/photo/ft40"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Photocells adjustable through 180°</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIPHOTOPOSTfourth"
                                                     href="/en/products/accessor/accessori/photo/post"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Posts for photocells</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIRXthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIRXRX2Hfourth"
                                                     href="/en/products/accessor/accessori/rx/rx2h"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Miniaturized receiver</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIRXRX4fourth"
                                                     href="/en/products/accessor/accessori/rx/rx4"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Plug-In receiver</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIRXRXMfourth"
                                                     href="/en/products/accessor/accessori/rx/rxm"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Universal receivers</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORISOLARthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORISOLAROTHERfourth"
                                                     href="/en/products/accessor/accessori/solar/other"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Accessories</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORITXthird"
                                      class="col-md-2 fourth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORITXSUBfourth"
                                                     href="/en/products/accessor/accessori/tx/sub"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Water resistant 4 channels transmitter</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORITXPLAYfourth"
                                                     href="/en/products/accessor/accessori/tx/play"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >4 Channels transmitter in ABS</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORITXTOUCHfourth"
                                                     href="/en/products/accessor/accessori/tx/touch"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >1/2 Channels touch transmitter</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTIARMMEWAfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIARMMEWA24Vfifth"
                                                     href="/en/products/gate/battenti/arm/mewa/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIARMMEWA230Vfifth"
                                                     href="/en/products/gate/battenti/arm/mewa/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTISWINGPS400fourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGPS40024Vfifth"
                                                     href="/en/products/gate/battenti/swing/ps400/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGPS400230Vfifth"
                                                     href="/en/products/gate/battenti/swing/ps400/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTISWINGRAY40fourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGRAY4024Vfifth"
                                                     href="/en/products/gate/battenti/swing/ray40/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTISWINGRAY40230Vfifth"
                                                     href="/en/products/gate/battenti/swing/ray40/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATEBATTENTIUNDERINTfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIUNDERINT24Vfifth"
                                                     href="/en/products/gate/battenti/under/int/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATEBATTENTIUNDERINT230Vfifth"
                                                     href="/en/products/gate/battenti/under/int/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkGATESCORREVOLISLIDETURBO80fourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO8024Vfifth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo80/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkGATESCORREVOLISLIDETURBO80230Vfifth"
                                                     href="/en/products/gate/scorrevoli/slide/turbo80/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORACCESSORISECTIONRAILfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORISECTIONRAIL1X3Bfifth"
                                                     href="/en/products/door/accessori/section/rail/1x3b"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >3-Pieces rail, 3100 mm</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORISECTIONRAIL3MBfifth"
                                                     href="/en/products/door/accessori/section/rail/3mb"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >1-Piece rail, 3100 mm</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORACCESSORISECTIONRAIL4MBfifth"
                                                     href="/en/products/door/accessori/section/rail/4mb"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >1-Piece rail, 4100 mm</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkDOORGARAGEOVERHEADBLINDOfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGEOVERHEADBLINDO24Vfifth"
                                                     href="/en/products/door/garage/overhead/blindo/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkDOORGARAGEOVERHEADBLINDO230Vfifth"
                                                     href="/en/products/door/garage/overhead/blindo/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETEfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE2LEAFfifth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/complete/2leaf"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding doors with 2 leaves</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE1LEAFfifth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/complete/1leaf"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding doors with 1 leaf</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE2LEAFTfifth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/complete/2leaft"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding telescopic door with 2+2 leaves</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDCOMPLETE1LEAFTfifth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/complete/1leaft"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding telescopic door with 1+1 leaf</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkAUTODOORPORTEAUTOMATICHESLIDEDKITfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDKIT2LEAFTfifth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/kit/2leaft"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding telescopic door with 2+2 leaves</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkAUTODOORPORTEAUTOMATICHESLIDEDKIT1LEAFTfifth"
                                                     href="/en/products/autodoor/porteautomatiche/slided/kit/1leaft"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >Sliding telescopic door with 1+1 leaf</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>
                                 <div id="boxlinkACCESSORACCESSORIFLASHLUMYfourth"
                                      class="col-md-2 fifth-level white-border text-white">
                                     <div class="col-megamenu">
                                         <ul class="list-unstyled">
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIFLASHLUMY24Vfifth"
                                                     href="/en/products/accessor/accessori/flash/lumy/24v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >24V</a></li>
                                             <li class="">
                                                 <a
                                                     id="linkACCESSORACCESSORIFLASHLUMY230Vfifth"
                                                     href="/en/products/accessor/accessori/flash/lumy/230v"
                                                     class="dropdown-toggle-custom"
                                                     role="button"
                                                     aria-expanded="false"
                                                 >230V</a></li>
                                         </ul>
                                     </div> <!-- col-megamenu.// -->
                                 </div>--}}
                            </div><!-- end row -->
                        </div> <!-- dropdown-mega-menu.// -->
                    </li>
                    <li class="nav-item dropdown has-megamenu">
                        <a href="" class="nav-link dropdown-toggle"
                           data-bs-toggle="dropdown"
                           role="button"
                           id="subdropdown2"
                           aria-haspopup="true"
                           aria-expanded="false"
                        >سابقة اعمال<span class="caret"></span></a>
                        <div class="dropdown-menu megamenu border-bottom"
                             role="menu" data-bs-popper="none">
                            <div class="row g-3 w-100">
                                <div class="offset-md-1 col-md-2 white-border text-white">
                                    <div class="col-megamenu first-level">
                                        <ul class="list-unstyled">
                                            <li class="">
                                                <a  id="linkGATEfirst"
                                                    class="dropdown-toggle-custom"
                                                    href="{{route('product','رولر شتر')}}"
                                                    role="button">
                                                    رولر شتر
                                                </a>
                                                <!-- / second level -->
                                            </li>
                                            <li class="">
                                                <a id="linkGATEfirst"
                                                   class="dropdown-toggle-custom"
                                                   role="button"
                                                   aria-expanded="false">
                                                    بوابات منزلقة ومفصلية اوتوماتيك
                                                </a>
                                                <!-- / second level -->
                                            </li>
                                            <li class="">
                                                <a id="linkGATEfirst"
                                                   class="dropdown-toggle-custom"
                                                   role="button"
                                                   aria-expanded="false">
                                                    الابواب الزجاجية المنزلقة
                                                </a>
                                                <!-- / second level -->
                                            </li>
                                            <li class="">
                                                <a id="linkGATEfirst"
                                                   class="dropdown-toggle-custom"
                                                   role="button"
                                                   aria-expanded="false">
حواجز مرورية                                                </a>
                                                <!-- / second level -->
                                            </li>

                                        </ul>
                                    </div> <!-- col-megamenu.// -->
                                </div><!-- end col-1 -->
                                <div id="boxlink0"
                                     class="col-md-2 second-level white-border text-white">
                                    <div class="col-megamenu">
                                        <ul class="list-unstyled">
                                        </ul>
                                    </div> <!-- col-megamenu.// -->
                                </div><!-- end col-3 -->
                                <div id="boxlink1"
                                     class="col-md-2 second-level white-border text-white">
                                    <div class="col-megamenu">
                                        <ul class="list-unstyled">
                                        </ul>
                                    </div> <!-- col-megamenu.// -->
                                </div><!-- end col-3 -->
                                <div id="boxlink2"
                                     class="col-md-2 second-level white-border text-white">
                                    <div class="col-megamenu">
                                        <ul class="list-unstyled">
                                        </ul>
                                    </div> <!-- col-megamenu.// -->
                                </div><!-- end col-3 -->
                                <div id="boxlink3"
                                     class="col-md-2 second-level white-border text-white">
                                    <div class="col-megamenu">
                                        <ul class="list-unstyled">
                                        </ul>
                                    </div> <!-- col-megamenu.// -->
                                </div><!-- end col-3 -->
                            </div><!-- end row -->
                        </div> <!-- dropdown-mega-menu.// -->
                    </li>

                    <li class="nav-item dropdown has-megamenu">
                        <a href="" class="nav-link dropdown-toggle"
                           data-bs-toggle="dropdown"
                           role="button"
                           id="subdropdown2"
                           aria-haspopup="true"
                           aria-expanded="false"
                        >البوم صور<span class="caret"></span></a>

                    </li>
                    <li class="nav-item dropdown has-megamenu">
                        <a href="/en/contatti"
                           class="nav-link"
                        >
                            الاخبار
                        </a>
                    </li>
                    <li class="nav-item dropdown has-megamenu">
                        <a href="/en/contatti"
                           class="nav-link"
                        >
                            تواصل معنا
                        </a>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right align-items-sm-center">
                    {{--                        <li class="dropdown has-megamenu area-personal-menu">--}}
                    {{--                            <a href="/en/login"--}}
                    {{--                               class="nav-link text-sm text-gray-700 dark:text-gray-500 underline"--}}
                    {{--                            >Login</a>--}}
                    {{--                        </li>--}}
                    <li class="dropdown search">
                        <a
                            id="btn-cerca"
                            class="nav-link dropdown-toggle"
                            data-bs-toggle="dropdown"
                            role="button"
                            aria-haspopup="true"
                            aria-expanded="false">
                            <i class="fas fa-search"></i>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <li>
                                <form class="col-12" method="get" action="/en/products">
                                    <input
                                        id="cerca"
                                        type="search"
                                        class="form-control"
                                        placeholder="search...."
                                        aria-label="Search"
                                        name="nav_search"
                                        value="">
                                </form>
                            </li>
                        </ul>
                    </li>
                    {{-- <li class="dropdown lingue-menu">
                         <a
                             href="#"
                             class="nav-link dropdown-toggle"
                             data-bs-toggle="dropdown"
                             role="button"
                             aria-haspopup="true"
                             aria-expanded="false">
                         <span class="text-uppercase">
                             en
                         </span>
                         </a>
                         <ul
                             class="dropdown-menu default-dropdown-menu"
                             aria-labelledby="dropdownMenuLingue">
                             <li class="">
                                 <a
                                     href="#"
                                     class="dropdown-item "
                                     onclick="location.href ='/it'">
                                     <img
                                         class="image"
                                         src="/icons/it.svg"
                                         alt="0">
                                     <span class="text-capitalize">
                                     Italiano
                                 </span>
                                 </a>
                             </li>
                             <li class="">
                                 <a
                                     href="#"
                                     class="dropdown-item active"
                                     onclick="location.href ='/en'">
                                     <img
                                         class="image"
                                         src="/icons/en.svg"
                                         alt="1">
                                     <span class="text-capitalize">
                                     English
                                 </span>
                                 </a>
                             </li>
                             <li class="">
                                 <a
                                     href="#"
                                     class="dropdown-item "
                                     onclick="location.href ='/es'">
                                     <img
                                         class="image"
                                         src="/icons/es.svg"
                                         alt="2">
                                     <span class="text-capitalize">
                                     Español
                                 </span>
                                 </a>
                             </li>
                             <li class="">
                                 <a
                                     href="#"
                                     class="dropdown-item "
                                     onclick="location.href ='/fr'">
                                     <img
                                         class="image"
                                         src="/icons/fr.svg"
                                         alt="3">
                                     <span class="text-capitalize">
                                     Français
                                 </span>
                                 </a>
                             </li>
                         </ul>
                     </li>--}}
                </ul>
            </div><!-- /.navbar-collapse -->

        </div><!-- /.container-fluid -->
    </nav>
</header>

    <main aria-live="polite" aria-atomic="true" class="position-relative">
        <div class="container-fluid p-0" id="home-page">
            <!--carousler-->
            <section class="slider">
                <div id="carouselExampleControls" class="carousel slide slide-container" data-bs-ride="carousel">
                    <div class="carousel-inner">

                        <div class="carousel-item active" data-bs-interval="5000">
                            <img src="{{asset('assets/images/product-showcase/images/ocr (4).jpeg')}}" class="img-fluid w-100"
                                 alt="Home-Page2016087701.jpg">

                        </div>
                        <div class="carousel-item " data-bs-interval="5000">
                            <img src="{{asset('assets/images/product-showcase/images/5df9157ad4087d4dcc15.jpeg')}}" class="img-fluid w-100"
                                 alt="Vista_06486741145.jpg">

                        </div>
                    </div>

                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                            data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                            data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </section>
            @yield('content')

        </div>
    </main>

    <div class="container-fluid" id="footer-container">
        <footer>
            <div class="row bg-dark-blue text-white">
                <div class="col-lg-6 col-12 mb-0 mb-md-4 pb-0 ">
                    <p>Follow us</p>
                    <ul class="list-unstyled social-icon social mb-0 mt-4">
                        <li class="icon">
                            <a href="https://www.facebook.com/pages/KEY-AUTOMATION/227631273939043" target="_blank">
                                <i class="fab fa-facebook"></i></a></li>
                        <li class="icon"><a href="https://www.instagram.com/italy/?feature=watch"
                                            target="_blank"><i class="fab fa-instagram"></i></a></li>
                        <li class="icon"><a href="http://www.youtube.com/user/?feature=watch"
                                            target="_blank"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                </div>
                <div class="col-lg-6 col-12 mb-0 mb-md-4 pb-0">
                    <ul class="list-unstyled related-links mb-0 mt-4">

                        <li>
                            <a href="/en/pages/privacy">
                                Privacy &amp; Cookies
                            </a>
                        </li>
                        <li>
                            <a href="/en/pages/terms-of-sales">
                                Terms of sales
                            </a>
                        </li>
                        <li>
                            <a href="/en/pages/legal-disclaimer">
                                Legal Disclaimer
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="logo mb-2"><img src="{{asset('assets/images/logo.png')}}" alt="key automation" width="175px"></div>
                <div class="text-center">
                    <p class="text-light"><small>GrandGate S.r.l. - Via Meucci 23, 30027 San Donà di Piave (VE) – Ph. +39 0421 307456 – VAT No. 03627650264 – Share Capital euro 154.000,00 i.v. <br/> Venice Business Register 03627650264 - REA VE 326953 - info@.it - www..com</small></p>
                </div>

            </div>
        </footer><!--end footer-->
    </div>


    <!-- Scripts -->
    <script src="https://.com/js/frontend/app.js"></script>

    <script src="https://.com/js/libs/OwlCarousel2/owl.carousel.js"></script>
    <script src="https://.com/js/libs/instafeed/instafeed.min.js"></script>
    <script defer src="https://.com/js/plugins/cookieconsent/cookieconsent.js"></script>
    <script defer src="https://.com/js/plugins/cookieconsent/settings.js"></script>

    <!-- Google Tag Manager -->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-B4WRFD7T1X"></script>
    <script type="text/plain" data-cookiecategory="analytics">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-B4WRFD7T1X');
  $(document).ready(function () {});









</script>
    <!-- sweetalerts -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        $(document).ready(function () {
            let toast1 = $('.toast');
            toast1.toast({
                delay: 50000000,
                animation: true
            });
            // $('#showtoast').on('click', function(e){
            //     e.preventDefault();
            toast1.toast('show');

            // })
            //  Sweet alert for all delete items
            $('.show_confirm_delete').click(function (event) {
                var form = $(this).closest("form");
                var name = $(this).data("name");
                event.preventDefault();
                swal({
                    title: `Are you sure you want to delete this item?`,

                    icon: "warning",
                    buttons: ["Cancel", "OK"],
                    dangerMode: true,
                })
                    .then((willDelete) => {
                        if (willDelete) {
                            form.submit();
                        }
                    });
            });

            //  Sweet alert for confirm add item in cart
            $('.show_confirm_item_add_to_cart').click(function (event) {
                link = this.href;
                event.preventDefault();
                swal({
                    title: `ADD ITEM TO CART`,
                    text: `Any dedicated discounts will be added directly to the shopping cart`,
                    icon: "https://.com/icons/cart.png",
                    buttons: ["Cancel", "OK"],
                    dangerMode: true,
                }).then((willAdd) => {
                    if (willAdd) {
                        return window.location.href = link;
                    }
                });
            });

            //  Sweet alert for confirm cart done
            $('.show_confirm_cart_done').click(function (event) {
                var form = $(this).closest("form");
                var name = $(this).data("name");
                form.submit();
            });

            // Tooltips initial

            $("body").tooltip({selector: '[data-toggle=tooltip]'});
        });
    </script>
    <script src="https://.com/js/libs/turnjs4/extras/jquery.min.1.7.js"></script>
    <script src="https://.com/js/libs/turnjs4/lib/turn.js"></script>
    <script src="https://.com/js/libs/turnjs4/lib/zoom.min.js"></script>

    <script>
        $(document).ready(function() {
            if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
                let deskContainer = document.getElementsByClassName("c-container");
                let mobileContainer = document.getElementsByClassName("c-mobile-container");
                $(deskContainer).addClass('d-none');
                $(mobileContainer).removeClass('d-none');

            }
        })


        const flyers = [{"id":9,"name":"AUTOMAZIONI PER PORTE E CANCELLI 2023","title_it":"AUTOMAZIONI PER PORTE E CANCELLI 2023","title_en":"GATES AND DOORS AUTOMATION 2023","title_es":"AUTOMATIZACI\u00d3N PARA PUERTAS Y CANCELAS 2023","title_fr":"AUTOMATISMES POUR PORTES ET PORTAILS 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":"[\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0001429105273.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00022054981708.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0003720706243.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00042001709549.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00051389379364.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0006927762613.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0007939546264.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00081697851027.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00091991463348.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00101720480790.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0011497240690.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00121506359077.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0013356143546.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00141256814483.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0015666122123.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00161730330646.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0017211511731.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0018754682562.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0019164787832.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00201328909056.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0021101035170.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0022743237087.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0023956518942.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00241698323754.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0025920150492.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00261151013952.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00271545840421.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00281177407551.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00291527954288.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0030581864185.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0031458900088.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00322027677258.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00331277504583.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0034181646767.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00351813448368.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00362114557058.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0037740985060.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0038370875069.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00391243808402.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0040159796776.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0041952796276.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0042896935701.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0043730790845.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00441639712965.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0045745208362.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00461606324421.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00471956950626.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0048903201198.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-004933113448.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0050746743034.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0051112396275.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00521340467922.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00532144001002.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0054348929662.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0055573697351.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00561818636218.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-005710906789.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00581829957925.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-005998325246.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0060527572126.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00611307996533.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00621013310227.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00632075874556.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00641471218921.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00651695409788.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00661200026404.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00671824283737.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00681752775111.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00692090490509.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00701594904114.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0071581225324.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0072149888524.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0073912264949.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0074943459072.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00751715888394.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00762073633575.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-007760133449.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00781734807285.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00791280280988.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00801635860645.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00811115119851.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0082270099708.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00831964924741.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00841824841691.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00851317854922.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0086386013383.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00871726106314.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-008875592180.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00891101353720.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0090961182848.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00911221309392.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-009274378478.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00932089732030.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-009434413676.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00951532139852.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0096749315064.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-009735845694.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00982104211889.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-00991116986065.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01002133801115.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0101719782791.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01021455209354.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01031640930481.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01041808650319.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0105388967621.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-010625908023.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0107740146735.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01081546192732.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01091233890175.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01101746524625.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01111053041890.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01121648912549.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01132012237672.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01141643823348.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01151780044613.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01161176043673.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01171449860084.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-011885779781.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0119620527182.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0120980302356.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01211596337748.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0122389445428.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01231296641455.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0124549422234.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01251703191954.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01261958455334.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01271544385784.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01281621036294.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0129835100903.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-0130545889229.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01311457972516.jpg\",\"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-2023_page-01321226249905.jpg\"]","book_images_en":"[\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00011232647518.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0002366295412.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0003262656361.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00041003497501.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00051569174662.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00062133401415.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00071412422129.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00081430804623.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00091508617658.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00101932796994.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0011318014591.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0012802826171.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00131750010856.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0014513754463.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0015327842284.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0016920154533.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00172001861996.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0018461979256.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0019622505893.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00201789996849.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0021307868104.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0022958393989.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00236083844.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00241462262243.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00251677841184.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0026806472912.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00271922915066.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00281362851083.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00292044970114.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00301131276316.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0031453303178.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00321248260735.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00331944193828.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0034148389986.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00351487179322.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-003612117079.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0037197553777.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00381048006075.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00391905481720.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0040460675073.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0041785243081.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00421636568474.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0043875646029.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00441140729697.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0045789692833.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00461189165177.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0047659957850.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0048968771230.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00492069359721.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0050759320511.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00511550182996.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00521710651722.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0053987255192.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00541733185404.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0055189980880.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0056135335965.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00571305662797.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00582099594673.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00592014580879.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0060891048878.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0061495358327.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00622002774313.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00631941320095.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00641718738673.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00651826477960.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0066902996515.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0067412460195.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00681780588581.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-006911105124.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0070947719752.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00711611454547.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0072984249938.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0073284169301.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0074999378788.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0075257939893.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00761133184495.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0077334050444.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00781839163598.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0079624306582.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00801855653196.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00811513296640.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00822017086344.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0083832326031.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0084100505047.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00851434031767.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00861826749485.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00871114550239.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00881658249491.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0089738420494.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0090972076299.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0091146685551.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00921577559911.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00931952303656.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00941774280853.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0095843134353.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00961300692950.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00971353768624.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00981929670484.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-00991131196508.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-010092884821.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0101974104061.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01021459102622.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-010326165310.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01041417011232.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01051615232012.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0106470555011.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01071334522396.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01081266229137.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0109113844410.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0110517724659.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01111048274277.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01121253629942.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0113848375493.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01141710279910.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01151548349750.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0116718703223.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0117648340654.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0118736771307.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0119971365388.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01201815792548.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01211927818856.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0122560931492.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0123229778413.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01241804365224.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0125388809025.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-012677942144.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01271196082482.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0128701679336.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01291653776851.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0130864988881.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-0131803593314.jpg\",\"000CATG000E23---GATES-AND-DOORS-AUTOMATION-2023_page-01321995166071.jpg\"]","book_images_es":"[\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00011481944755.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0002902336092.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00031981486003.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00042021255462.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0005255049429.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00062084764262.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00072028322097.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00082000152470.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00091871943652.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00101766531034.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00111983990180.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0012957656153.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00132107797686.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0014805782205.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00151711317545.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00161892584462.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00171947092295.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00181839103272.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00191990112765.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0020382889970.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0021585287656.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0022581995514.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00231355742419.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00242057585756.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0025258984659.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-002696921974.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00271741536634.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00281189044421.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00291458793451.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00301065230121.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00311034296452.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00321549725927.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00331600104826.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00341393687651.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00351083753317.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00361490337579.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00371797235025.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00381734772103.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00391802181581.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00401026823607.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00411878531042.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0042277400001.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-004385287619.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0044214012694.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00451520697946.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00461545371610.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0047372972084.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0048412073545.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00491490934600.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00502066099279.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00511869716124.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0052367295621.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00535969521.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00541079940019.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00551251624595.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0056670975589.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00571164640001.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00581609024143.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0059271362313.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00601457117146.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0061618272346.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00621050837773.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0063399698910.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00642021266451.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00651426601856.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0066902274365.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-006746960039.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00681728053067.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0069606402006.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0070838195112.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00711242706979.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0072255806333.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00731601512023.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00741297141672.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0075367304850.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0076351282664.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0077565028739.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-007817276840.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0079260425162.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0080181287272.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0081540546164.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0082281780262.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00831696963319.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00841264952725.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0085614718134.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0086270316891.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0087225675199.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0088646680538.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0089385368783.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0090707642592.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-009187720674.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0092382029593.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00931819163433.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0094830896037.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-00951967316555.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0096296143329.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0097889033380.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0098338290215.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0099146788716.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01001978426550.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01011131244271.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01021779132077.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01031516887574.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01041134054722.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0105858340744.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0106854660698.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0107345063480.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01081498818516.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01091428104304.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0110681210270.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0111365333001.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01121211879206.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-011313190769.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01141750759952.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01151512843756.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01161357022805.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01171589479223.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01181592618843.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01191615576182.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01201705556330.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0121996109677.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01221018826472.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0123339746758.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0124866995289.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0125706946569.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0126250385489.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01271763583497.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0128769748212.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0129193194297.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01301286075273.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-01311340038537.jpg\",\"000CATG000S23---AUTOMATIZACI\\u00d3N-PARA-PUERTAS-Y-CANCELAS-2023_page-0132829942557.jpg\"]","book_images_fr":"[\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0001721624301.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00021746929965.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0003432323580.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0004944803772.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00051686364698.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00061628493764.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0007170174367.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0008408699297.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00091563824556.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0010861960384.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0011360280137.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00121073614267.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00131632511960.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00141347678315.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0015789243802.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00161960264950.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00171964047754.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-001836477224.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00191415828019.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0020393115669.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0021640977330.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00221230122467.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00231829854835.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0024836002751.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00251367166819.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0026525818551.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00271723798964.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0028954393123.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0029846784912.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00301542049269.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0031344121828.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00321240316381.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0033954735742.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-003489587107.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0035237944980.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0036718926880.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0037970333119.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00381460214270.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0039676607107.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0040506202608.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00412111420812.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00421828825916.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0043748863701.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0044664656812.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00452039216674.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0046433867687.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00471325652386.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0048559512692.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0049165044603.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00502125114935.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00511435083587.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00522090117828.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0053476413283.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0054228367736.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00551694112592.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0056356046355.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0057301538262.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-005818777194.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00593645236.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00601180407737.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0061652567150.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00621512824140.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00631069924482.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0064151242511.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0065841375357.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0066462182716.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0067726243555.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0068863724351.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0069931348437.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00701785372416.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0071545029803.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00721692942432.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00731356339759.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0074817112756.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0075809247442.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00761467197101.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0077741779242.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00781858751119.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00791134799617.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0080346153129.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00811792774668.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0082605099301.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00831841573132.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0084959086676.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0085845928981.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0086947664657.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0087311079236.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00881504631726.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00891646687767.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0090200839598.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00911712678696.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00921592904674.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0093806078898.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0094575621648.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0095137510523.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00961072000989.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0097934334395.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-00981943255305.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0099687731235.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0100807090277.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0101362344336.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01021181444761.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0103914159223.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0104598961389.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01051605428703.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0106436090631.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01071942536131.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01081294574589.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01091516240963.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01101210692621.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0111687665255.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01121678913144.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01131194987909.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0114833005659.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0115590512725.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01161834042941.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01172055141852.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01181658182518.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01191753600158.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0120830269047.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01211505472184.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0122988321171.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01231129847119.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0124347204136.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0125115066778.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01261787139632.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0127721688003.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01281093059173.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01291452309069.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01301749193339.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-01311614481480.jpg\",\"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023_page-0132718239352.jpg\"]","book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG000I23---AUTOMAZIONI-PER-PORTE-E-CANCELLI-20232129721775.pdf","pdf_en":"000CATG000E23---GATES-AND-DOORS-AUTOMATION-202378427191.pdf","pdf_es":"000CATG000S23---AUTOMATIZACI\u00d3N-PARA-PUERTAS-Y-CANCELAS-20231514486690.pdf","pdf_fr":"000CATG000F23---AUTOMATISMES-POUR-PORTES-ET-PORTAILS-2023116755292.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"gates","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-13T16:11:57.000000Z","updated_at":"2023-03-14T09:45:14.000000Z"},{"id":11,"name":"AUTOMAZIONI PER PORTE PEDONALI 2023","title_it":"AUTOMAZIONI PER PORTE PEDONALI 2023","title_en":"AUTOMATION FOR PEDESTRIAN DOORS 2023","title_es":"AUTOMATISMOS PARA PUERTAS PEATONALES 2023","title_fr":"AUTOMATISMES POUR PORTES PI\u00c9TONNES 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":"[\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00011912128051.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00021955752428.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00031271139586.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0004856136203.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00051013290806.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00061505742389.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0007234581248.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00082031717841.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00091576750611.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00101124055420.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0011530087328.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00121859993369.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0013870551315.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00141070868651.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00151232578005.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00161525045635.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00171664770332.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00186589746.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00191523547193.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0020390826249.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00211058338885.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00221037149873.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0023612028098.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-00241863627889.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0025873996286.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-002690519611.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-0027299042983.jpg\",\"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-2023_page-002895817902.jpg\"]","book_images_en":"[\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0001956973365.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00021984980484.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00031785795477.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0004136373140.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00051834373284.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00061226743761.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0007487379439.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00081032075299.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0009306262686.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0010842862156.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00111239181577.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0012185035771.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00131312847937.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0014780519604.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0015767361945.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00161706868413.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00171047293658.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0018291010534.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00191474721093.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00201508512995.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00211137604995.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00221105681371.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00231116946283.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0024673240219.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0025979219001.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0026363475978.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-00271371155493.jpg\",\"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023_page-0028233959431.jpg\"]","book_images_es":"[\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00011383460229.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00021971825341.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00031057356857.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00041967090213.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00051154166892.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00061922324818.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00071451695557.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0008124215640.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00092088061957.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-001076768184.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00111864981401.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0012662136834.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0013725545923.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0014714105026.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00151792260278.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0016396221644.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0017936017066.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00181234682467.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00191591582242.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0020776331338.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00211967604157.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00222078953857.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00231755553505.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0024760771885.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00251088012833.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-00261752705578.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0027899299633.jpg\",\"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023_page-0028498531441.jpg\"]","book_images_fr":"[\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0001807785831.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0002313787961.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0003798730937.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00041912865340.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0005464619021.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00062074116857.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00071427994271.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00082004882888.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00091032141758.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0010540870035.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00111430743947.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0012725732911.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00131982577213.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0014646150953.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-001537992410.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00161072359028.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00179436173.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0018770722699.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0019587657707.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00201744248844.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00212123250075.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00221335620101.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00231429007571.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0024339277464.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-002572078355.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00261520276155.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-00271558773777.jpg\",\"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\\u00c9TONNES-2023_page-0028375913767.jpg\"]","book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG003I23---AUTOMAZIONI-PER-PORTE-PEDONALI-202327869254.pdf","pdf_en":"000CATG003E23---AUTOMATION-FOR-PEDESTRIAN-DOORS-2023753823006.pdf","pdf_es":"000CATG003S23---AUTOMATISMOS-PARA-PUERTAS-PEATONALES-2023592981254.pdf","pdf_fr":"000CATG003F23---AUTOMATISMES-POUR-PORTES-PI\u00c9TONNES-2023574722568.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"porte_auto","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-13T16:23:47.000000Z","updated_at":"2023-03-14T08:01:58.000000Z"},{"id":12,"name":"ILLUMINAZIONE PER L\u2019ESTERNO 2023","title_it":"ILLUMINAZIONE PER L\u2019ESTERNO 2023","title_en":"OUTDOOR LIGHTING 2023","title_es":"ILUMINACI\u00d3N PARA EL EXTERIOR 2023","title_fr":"\u00c9CLAIRAGE POUR L\u2019EXT\u00c9RIEUR 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":"[\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00011766727532.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00021858253383.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0003967916015.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-000426171424.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0005478717153.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00061509967603.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0007660898051.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0008252675660.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0009312969800.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00102125864542.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00114809488.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0012811341153.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-001365959140.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00142002048210.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00151173877.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00161864883246.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00175391215.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00182047171878.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0019219176839.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00201374145480.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0021832373485.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00221787079942.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00231841575099.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00241947365389.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0025825539420.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0026270778720.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0027405743938.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0028793547269.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-0029471297119.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00301535402781.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00311861855473.jpg\",\"000CATG002I23---ILLUMINAZIONE-PER-L\\u2019ESTERNO-2023_page-00321803725853.jpg\"]","book_images_en":"[\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0001116531840.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00021744554977.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0003461407579.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00041081071926.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00051639034883.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0006947552328.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00071525733767.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00081379593532.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00091152720548.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0010347517088.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00111041377618.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00121732042746.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00131785556590.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00141070055991.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00151992552527.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00162109506715.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00171147114807.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0018100010689.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00191343541439.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00201443267961.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0021164887960.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00222013745789.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0023396829303.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00241984467867.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00251518902324.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0026504419256.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00271193755519.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00281076644405.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0029363242268.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00301667358791.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-0031364038441.jpg\",\"000CATG002E23---OUTDOOR-LIGHTING-2023_page-00321115552702.jpg\"]","book_images_es":"[\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0001589233273.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00021740117328.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00031351213597.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-000481689532.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00051087654602.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-000645469798.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0007160677762.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00081538207813.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0009415778557.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0010890262025.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00111650227489.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0012634936350.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0013752369692.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00142120765075.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0015287879069.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0016376746449.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0017566567741.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0018117584909.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00191462722306.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0020512678892.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0021204181724.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0022330467706.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00232079967482.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0024339046971.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0025428646771.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00261861521385.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00271824108029.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0028978404788.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00291585967702.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0030548919565.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-00312029535658.jpg\",\"000CATG002S23---ILUMINACI\\u00d3N-PARA-EL-EXTERIOR-2023_page-0032836018418.jpg\"]","book_images_fr":"[\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00012004374255.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00022087041143.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0003796906824.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0004751611242.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0005661695402.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00061515226282.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0007998576665.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0008331265569.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0009194416717.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0010178198620.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0011295486661.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0012996048825.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0013142368918.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0014439553474.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0015617120094.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00161632423751.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00171086253884.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0018947017994.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00191081909489.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-002081799290.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00211983562950.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0022709629038.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00231585279776.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0024739403631.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00251137461911.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0026914147126.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00272086008661.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0028365157685.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00292115493242.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0030264895638.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-0031208571424.jpg\",\"000CATG002F23---\\u00c9CLAIRAGE-POUR-L\\u2019EXT\\u00c9RIEUR-2023_page-00321660383301.jpg\"]","book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG002I23---ILLUMINAZIONE-PER-L\u2019ESTERNO-2023465930759.pdf","pdf_en":"000CATG002E23---OUTDOOR-LIGHTING-20231487940991.pdf","pdf_es":"000CATG002S23---ILUMINACI\u00d3N-PARA-EL-EXTERIOR-20231582880009.pdf","pdf_fr":"000CATG002F23---\u00c9CLAIRAGE-POUR-L\u2019EXT\u00c9RIEUR-2023380558576.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"garden","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-13T16:25:31.000000Z","updated_at":"2023-03-14T08:10:06.000000Z"},{"id":13,"name":"BEST SELLERS 2023","title_it":"BEST SELLERS 2023","title_en":"BEST SELLERS 2023","title_es":"LOS M\u00c1S VENDIDOS 2023","title_fr":"LES PLUS VENDUS 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":"[\"000CATG004I23---BEST-SELLERS-2023_page-0001849888970.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00021546676400.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0003799574698.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0004872809917.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0005219596327.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00062108928115.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0007251454016.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-000869780422.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0009232751752.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00101897238110.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0011501492848.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00121940590506.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00131460696508.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0014120691795.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00151021454543.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00161562182404.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00172040604854.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0018122009637.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0019232328935.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-002021002386.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0021817882628.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0022265312652.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-00231501385537.jpg\",\"000CATG004I23---BEST-SELLERS-2023_page-0024625819020.jpg\"]","book_images_en":"[\"000CATG004E23---BEST-SELLERS-2023_page-00011898954129.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0002972685942.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00031091605193.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00041653768063.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0005952385127.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0006919362124.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-000786996437.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00081102948554.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00091815897623.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00101180833231.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0011781098404.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00121273104802.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0013766256991.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0014866317941.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00151377457468.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0016174012147.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00172133449975.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0018643480430.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0019309687287.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0020613436563.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-00211746797911.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0022165836445.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0023696658287.jpg\",\"000CATG004E23---BEST-SELLERS-2023_page-0024708116103.jpg\"]","book_images_es":"[\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-000161704061.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0002631261190.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0003138927089.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0004380354310.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0005143312135.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0006338183959.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0007709670265.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00081723108843.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00091305284944.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00101496942907.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00112020559371.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0012392670811.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00131989379495.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0014404029591.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0015338260025.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0016390058719.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00171270132071.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0018592096828.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00191825856432.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0020435665175.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00211498657570.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0022646890732.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-00231790197488.jpg\",\"000CATG004S23---LOS-M\\u00c1S-VENDIDOS-2023_page-0024600492677.jpg\"]","book_images_fr":"[\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00011552114830.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00021147673793.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00031286666960.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0004396429125.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0005699225131.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00061206806354.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0007753999081.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00082128372495.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0009105463951.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0010662744858.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00111578197291.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-001277405325.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00131719651649.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00141587674365.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00151152934843.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0016670860392.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-001715484827.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00181471898876.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00191359442898.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00201293276250.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0021517558547.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0022127984558.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-00231906600633.jpg\",\"000CATG004F23---LES-PLUS-VENDUS-2023_page-0024158067447.jpg\"]","book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG004I23---BEST-SELLERS-20232070896331.pdf","pdf_en":"000CATG004E23---BEST-SELLERS-20231998806097.pdf","pdf_es":"000CATG004S23---LOS-M\u00c1S-VENDIDOS-2023285182720.pdf","pdf_fr":"000CATG004F23---LES-PLUS-VENDUS-20231985533413.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"best_seller","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-13T16:27:30.000000Z","updated_at":"2023-03-14T08:14:13.000000Z"},{"id":14,"name":"AUTOMATIZA\u00c7\u00c3O DE PORT\u00d5ES E PORTAS 2023","title_it":"AUTOMATIZA\u00c7\u00c3O DE PORT\u00d5ES E PORTAS 2023","title_en":"AUTOMATIZA\u00c7\u00c3O DE PORT\u00d5ES E PORTAS 2023","title_es":"AUTOMATIZA\u00c7\u00c3O DE PORT\u00d5ES E PORTAS 2023","title_fr":"AUTOMATIZA\u00c7\u00c3O DE PORT\u00d5ES E PORTAS 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":null,"book_images_en":null,"book_images_es":null,"book_images_fr":null,"book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG000PT23-\u2013-AUTOMATIZA\u00c7\u00c3O-DE-PORT\u00d5ES-E-PORTAS--2023133448739.pdf","pdf_en":"000CATG000PT23-\u2013-AUTOMATIZA\u00c7\u00c3O-DE-PORT\u00d5ES-E-PORTAS--2023884839487.pdf","pdf_es":"000CATG000PT23-\u2013-AUTOMATIZA\u00c7\u00c3O-DE-PORT\u00d5ES-E-PORTAS--2023360654680.pdf","pdf_fr":"000CATG000PT23-\u2013-AUTOMATIZA\u00c7\u00c3O-DE-PORT\u00d5ES-E-PORTAS--20231285329258.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"porte_auto","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-14T09:55:21.000000Z","updated_at":"2023-03-14T16:05:10.000000Z"},{"id":15,"name":"AUTOMA\u00c7\u00d5ES PARA PORTAS PEDONAIS 2023","title_it":"AUTOMA\u00c7\u00d5ES PARA PORTAS PEDONAIS 2023","title_en":"AUTOMA\u00c7\u00d5ES PARA PORTAS PEDONAIS 2023","title_es":"AUTOMA\u00c7\u00d5ES PARA PORTAS PEDONAIS 2023","title_fr":"AUTOMA\u00c7\u00d5ES PARA PORTAS PEDONAIS 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":null,"book_images_en":null,"book_images_es":null,"book_images_fr":null,"book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG003F23---AUTOMA\u00c7\u00d5ES-PARA-PORTAS-PEDONAIS-2023612166080.pdf","pdf_en":"000CATG003F23---AUTOMA\u00c7\u00d5ES-PARA-PORTAS-PEDONAIS-2023739710157.pdf","pdf_es":"000CATG003F23---AUTOMA\u00c7\u00d5ES-PARA-PORTAS-PEDONAIS-2023924231636.pdf","pdf_fr":"000CATG003F23---AUTOMA\u00c7\u00d5ES-PARA-PORTAS-PEDONAIS-2023274427973.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"porte_auto","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-14T09:58:23.000000Z","updated_at":"2023-03-14T16:04:49.000000Z"},{"id":16,"name":"ILUMINA\u00c7\u00c3O PARA O EXTERIOR 2023","title_it":"ILUMINA\u00c7\u00c3O PARA O EXTERIOR 2023","title_en":"ILUMINA\u00c7\u00c3O PARA O EXTERIOR 2023","title_es":"ILUMINA\u00c7\u00c3O PARA O EXTERIOR 2023","title_fr":"ILUMINA\u00c7\u00c3O PARA O EXTERIOR 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":null,"book_images_en":null,"book_images_es":null,"book_images_fr":null,"book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG002F23---ILUMINA\u00c7\u00c3O-PARA-O-EXTERIOR-2023657092740.pdf","pdf_en":"000CATG002F23---ILUMINA\u00c7\u00c3O-PARA-O-EXTERIOR-202361782959.pdf","pdf_es":"NULL","pdf_fr":"000CATG002F23---ILUMINA\u00c7\u00c3O-PARA-O-EXTERIOR-2023187457378.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"garden","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-14T10:04:48.000000Z","updated_at":"2023-03-14T16:04:34.000000Z"},{"id":17,"name":"MELHORES VENDEDORES 2023","title_it":"MELHORES VENDEDORES 2023","title_en":"MELHORES VENDEDORES 2023","title_es":"MELHORES VENDEDORES 2023","title_fr":"MELHORES VENDEDORES 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":null,"book_images_en":null,"book_images_es":null,"book_images_fr":null,"book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG004F23---MELHORES-VENDEDORES-20231573789112.pdf","pdf_en":"000CATG004F23---MELHORES-VENDEDORES-2023321669812.pdf","pdf_es":"NULL","pdf_fr":"000CATG004F23---MELHORES-VENDEDORES-202326867004.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"best_seller","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-14T10:05:11.000000Z","updated_at":"2023-03-14T16:04:19.000000Z"},{"id":18,"name":"AUTOMATYKA DO DRZWI I BRAMY 2023","title_it":"AUTOMATYKA DO DRZWI I BRAMY 2023","title_en":"AUTOMATYKA DO DRZWI I BRAMY 2023","title_es":"AUTOMATYKA DO DRZWI I BRAMY 2023","title_fr":"AUTOMATYKA DO DRZWI I BRAMY 2023","title_pl":null,"title_hu":null,"title_sk":null,"title_de":null,"title_nl":null,"title_pt":null,"book_images_it":null,"book_images_en":null,"book_images_es":null,"book_images_fr":null,"book_images_pl":null,"book_images_hu":null,"book_images_sk":null,"book_images_de":null,"book_images_nl":null,"book_images_pt":null,"pdf_it":"000CATG000P23---AUTOMATYKA-DO-DRZWI-I-BRAMY-2023233591539.pdf","pdf_en":"000CATG000P23---AUTOMATYKA-DO-DRZWI-I-BRAMY-2023309901553.pdf","pdf_es":"000CATG000P23---AUTOMATYKA-DO-DRZWI-I-BRAMY-20231123177158.pdf","pdf_fr":"000CATG000P23---AUTOMATYKA-DO-DRZWI-I-BRAMY-20231572131928.pdf","pdf_pl":null,"pdf_hu":null,"pdf_sk":null,"pdf_de":null,"pdf_nl":null,"pdf_pt":null,"display":"gates","date_begin":"2023-03-14","date_end":null,"published":1,"deleted_at":null,"created_at":"2023-03-14T10:06:11.000000Z","updated_at":"2023-03-14T16:04:05.000000Z"}]
        const path = "https:\/\/.com\/media\/flyer\/images\/"
        let elements = [];


        flyers.forEach((element, index) => {
            let imgs = JSON.parse(element['book_images_it']);
            imgs = path+imgs[0];

            var tmpImg = new Image();
            tmpImg.src=imgs;
            var img_w = 1200
            var img_h = 848;

            $(tmpImg).one('load',function(){
                img_w = tmpImg.width;
                img_h = tmpImg.height;

            });


            elements.push(document.getElementById("flyer-container_"+index));

            let flipbook_id = "#flipbook_"+index;
            let z_viewport = '#zoom-viewport_'+index

            var div_w = $(flipbook_id).width();


            $(window).resize(function(){
                resizeViewport(flipbook_id, z_viewport);
            });


            $(flipbook_id).turn({
                width: '100%',
                height: img_h * (div_w/2) / img_w,
                // height: img_h,
                autoCenter: true
                //   elevation: 50,
            });
            $(z_viewport).zoom({
                flipbook: $(flipbook_id)
            });

            $(z_viewport).bind('zoom.tap', zoomTo);
            //Must be called initially to setup the size
            resizeViewport(flipbook_id, z_viewport);

            function zoomTo(event) {
                setTimeout(function() {
                    if ($(z_viewport).data().regionClicked) {
                        $(z_viewport).data().regionClicked = false;
                    } else {
                        if ($(z_viewport).zoom('value')==1) {
                            $(z_viewport).zoom('zoomIn', event);
                        } else {
                            $(z_viewport).zoom('zoomOut');
                        }
                    }
                }, 1);
            }

            if (document.addEventListener) {
                document.addEventListener('fullscreenchange', exitHandler, false);
                document.addEventListener('mozfullscreenchange', exitHandler, false);
                document.addEventListener('MSFullscreenChange', exitHandler, false);
                document.addEventListener('webkitfullscreenchange', exitHandler, false);
            }
            function exitHandler() {
                if (
                    (typeof document.webkitIsFullScreen !== 'undefined' && !document.webkitIsFullScreen) ||
                    (typeof document.mozFullScreen !== 'undefined' && !document.mozFullScreen) ||
                    (typeof document.msFullscreenElement !== 'undefined' && document.msFullscreenElement !== null)) {
                    // Run code on exit
                    $('#close_fullscreen_'+index).addClass('hide');
                    $('#fullscreen_'+index).removeClass('hide');

                    resizeFlippingBook(flipbook_id, z_viewport, index, img_w, img_h);
                }
            }
            $(".prev-page_"+index).click(function(e){
                e.preventDefault();
                $(flipbook_id).turn("previous");
            });

            $(".next-page_"+index).click(function(e){
                e.preventDefault();
                $(flipbook_id).turn("next");
            });

            $('#close_fullscreen_'+index).click(function() {
                $('#close_fullscreen_'+index).addClass('hide');
                $('#fullscreen_'+index).removeClass('hide');

                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                }

                exitHandler();
            });

            $('#fullscreen_'+index).click(function() {
                console.log(index);
                $(z_viewport).zoom('zoomOut');
                $('#fullscreen_'+index).addClass('hide');
                $('#close_fullscreen_'+index).removeClass('hide');

                if (elements[index].requestFullcreen) {
                    elements[index].requestFullcreen({ navigationUI: "show" })
                } else if (elements[index].mozRequestFullScreen) { /* Firefox */
                    console.log('firefox');
                    elements[index].mozRequestFullScreen()
                } else if (elements[index].webkitRequestFullscreen) { /* Chrome, Safari & Opera */
                    console.log('chrome');
                    elements[index].webkitRequestFullscreen()
                }

                resizeFlippingBook(flipbook_id, z_viewport, index, img_w, img_h);
            });

            $(z_viewport).on('zoom.zoomIn', function() {
                // $('#zoom_in_btn').addClass('hide');
                // $('#zoom_out_btn').removeClass('hide');
                $(z_viewport).addClass('zoomed');
            });

            $(z_viewport).on('zoom.zoomOut', function() {
                // $('#zoom_out_btn').addClass('hide');
                // $('#zoom_in_btn').removeClass('hide');
                $(z_viewport).removeClass('zoomed');
            });

            // $('#zoom_in_btn').click(function() {
            //     $(z_viewport).zoom('zoomIn');
            // });
            // $('#zoom_out_btn').click(function() {
            //     $(z_viewport).zoom('zoomOut');
            // });
        });

        function resizeFlippingBook(f_id, z_id, index, width, height) {

            setTimeout(function() {
                var x = $("#flyer-container_"+index).height();
                console.log(x);
                $(z_id).css({
                    width: '100%',
                    height: (x)
                }).zoom('resize');
                var new_div_w = $("#flyer-container_"+index).width();
                $(f_id).turn("size", '100%', ( height * (new_div_w/2) / width));

                resizeViewport(f_id, z_id);
            }, 1000);
        }

        function resizeViewport(id, z_viewport) {
            var width = $(id).width(),
                height = $(id).height(),
                options = $(id).turn('options');
            $(z_viewport).css({
                width: width,
                height: height
            }).zoom('resize');
        }

    </script>
    <script type="text/javascript">
        //    window.addEventListener("resize", function () {
        //        "use strict";
        //        window.location.reload();
        //    });
        document.addEventListener("DOMContentLoaded", function () {
            // Prevent closing from click inside dropdown
            document.querySelectorAll('.main-header .dropdown-menu').forEach(function (element) {
                element.addEventListener('click', function (e) {
                    e.stopPropagation();
                });
            });
            // make it as accordion for smaller screens
            if (window.innerWidth < 992) {
                // close all inner dropdowns when parent is closed
                document.querySelectorAll('.navbar .dropdown').forEach(function (everydropdown) {
                    everydropdown.addEventListener('hidden.bs.dropdown', function () {
                        // after dropdown is hidden, then find all submenus
                        this.querySelectorAll('.megasubmenu').forEach(function (everysubmenu) {
                            // hide every submenu as well
                            everysubmenu.style.display = 'none';
                        });
                    })
                });
                document.querySelectorAll('.has-megasubmenu a').forEach(function (element) {
                    element.addEventListener('click', function (e) {
                        let nextEl = this.nextElementSibling;
                        if (nextEl && nextEl.classList.contains('megasubmenu')) {
                            // prevent opening link if link needs to open dropdown
                            e.preventDefault();
                            if (nextEl.style.display === 'block') {
                                nextEl.style.display = 'none';
                            } else {
                                nextEl.style.display = 'block';
                            }

                        }
                    });
                })
            } else {
                // end if innerWidth
                $(document).ready(function () {
                    $('.first-level li a').mouseover(function () {
                        if (this.id) {
                            $(".second-level").hide();
                            $(".third-level").hide();
                            $(".fourth-level").hide();
                            $(".fifth-level").hide();
                        }
                        $('.second-level').hide().filter('#box' + this.id).fadeIn();
                    });
                    $('.second-level li a').mouseover(function () {
                        if (this.id) {
                            $(".third-level").hide();
                            $(".fourth-level").hide();
                            $(".fifth-level").hide();
                        }
                        $('.third-level').hide().filter('#box' + this.id).fadeIn();
                    });
                    $('.third-level li a').mouseover(function () {
                        if (this.id) {
                            $(".fourth-level").hide();
                            $(".fifth-level").hide();
                        }
                        $('.fourth-level').hide().filter('#box' + this.id).fadeIn();
                    });
                    $('.fourth-level li a').mouseover(function () {
                        if (this.id) {
                            // $(".fifth-level").hide();
                        }
                        $('.fifth-level').hide().filter('#box' + this.id).fadeIn();
                    });

                    $('.main-header .nav-link').hover(function () {
                        $(this).toggleClass('fw-bold')
                    })
                });
            }
        });
        // DOMContentLoaded  end
        $("#btn-cerca").click(function() {
            $("#cerca").focus();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.selectpicker').selectpicker();
        })
    </script>
    <!-- Scripts -->
    <script src="{{asset('assets/js/app.js')}}"></script>

    <script src="{{asset('assets/js/owl.carousel.js')}}"></script>
    <script src="https://.com/js/libs/instafeed/instafeed.min.js"></script>
    <script defer src="https://.com/js/plugins/cookieconsent/cookieconsent.js"></script>
    <script defer src="https://.com/js/plugins/cookieconsent/settings.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Google Tag Manager -->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-B4WRFD7T1X"></script>
    <script type="text/plain" data-cookiecategory="analytics">
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-B4WRFD7T1X');
  $(document).ready(function () {});









</script>
    <!-- sweetalerts -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        $(document).ready(function () {
            let toast1 = $('.toast');
            toast1.toast({
                delay: 50000000,
                animation: true
            });
            // $('#showtoast').on('click', function(e){
            //     e.preventDefault();
            toast1.toast('show');

            // })
            //  Sweet alert for all delete items
            $('.show_confirm_delete').click(function (event) {
                var form = $(this).closest("form");
                var name = $(this).data("name");
                event.preventDefault();
                swal({
                    title: `Are you sure you want to delete this item?`,

                    icon: "warning",
                    buttons: ["Cancel", "OK"],
                    dangerMode: true,
                })
                    .then((willDelete) => {
                        if (willDelete) {
                            form.submit();
                        }
                    });
            });

            //  Sweet alert for confirm add item in cart
            $('.show_confirm_item_add_to_cart').click(function (event) {
                link = this.href;
                event.preventDefault();
                swal({
                    title: `ADD ITEM TO CART`,
                    text: `Any dedicated discounts will be added directly to the shopping cart`,
                    icon: "https://.com/icons/cart.png",
                    buttons: ["Cancel", "OK"],
                    dangerMode: true,
                }).then((willAdd) => {
                    if (willAdd) {
                        return window.location.href = link;
                    }
                });
            });

            //  Sweet alert for confirm cart done
            $('.show_confirm_cart_done').click(function (event) {
                var form = $(this).closest("form");
                var name = $(this).data("name");
                form.submit();
            });

            // Tooltips initial

            $("body").tooltip({selector: '[data-toggle=tooltip]'});
        });
    </script>
    <script>

        $(document).ready(function(){
            $(".owl-carousel.prodotti").owlCarousel({
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: false,
                    },
                    600: {
                        items: 3,
                        nav: true
                    }
                }
            });

            var feed = new Instafeed({
                accessToken: "IGQVJYQkU1QmhFc0V1emhBSHlLMGVZAa1d4Q0xPLWMzUHVHemdIeGh5NUJBcHpvLWFQWmpDRFhHemFuUkRObkZAUZA1JHUnF6WWZAGa0M4dmZAfMEhlN0FLbGI1emJ6ZAWJiQkFzLTg0bk1wMFVYei1kNzE3NQZDZD",
                template: "<div class='col-xs-2 col-sm-3 p-1'><a href='https://www.instagram.com/italy/' target='_blank'><div class='item' style='background-image: url(#image#);'><i class='fab fa-2x fa-instagram'></i></div></a></div>",
                templateBoundaries: ['#','#'],
                limit: 8,
                debug: false,
                after: function runMe(){

                }
            });
            feed.run();

        });
    </script>

    <script type="text/javascript">
        //    window.addEventListener("resize", function () {
        //        "use strict";
        //        window.location.reload();
        //    });
        document.addEventListener("DOMContentLoaded", function () {
            // Prevent closing from click inside dropdown
            document.querySelectorAll('.main-header .dropdown-menu').forEach(function (element) {
                element.addEventListener('click', function (e) {
                    e.stopPropagation();
                });
            });
            // make it as accordion for smaller screens
            if (window.innerWidth < 992) {
                // close all inner dropdowns when parent is closed
                document.querySelectorAll('.navbar .dropdown').forEach(function (everydropdown) {
                    everydropdown.addEventListener('hidden.bs.dropdown', function () {
                        // after dropdown is hidden, then find all submenus
                        this.querySelectorAll('.megasubmenu').forEach(function (everysubmenu) {
                            // hide every submenu as well
                            everysubmenu.style.display = 'none';
                        });
                    })
                });
                document.querySelectorAll('.has-megasubmenu a').forEach(function (element) {
                    element.addEventListener('click', function (e) {
                        let nextEl = this.nextElementSibling;
                        if (nextEl && nextEl.classList.contains('megasubmenu')) {
                            // prevent opening link if link needs to open dropdown
                            e.preventDefault();
                            if (nextEl.style.display === 'block') {
                                nextEl.style.display = 'none';
                            } else {
                                nextEl.style.display = 'block';
                            }

                        }
                    });
                })
            } else {
                // end if innerWidth
                $(document).ready(function () {
                    $('.first-level li a').mouseover(function () {
                        if (this.id) {
                            $(".second-level").hide();
                            $(".third-level").hide();
                            $(".fourth-level").hide();
                            $(".fifth-level").hide();
                        }
                        $('.second-level').hide().filter('#box' + this.id).fadeIn();
                    });
                    $('.second-level li a').mouseover(function () {
                        if (this.id) {
                            $(".third-level").hide();
                            $(".fourth-level").hide();
                            $(".fifth-level").hide();
                        }
                        $('.third-level').hide().filter('#box' + this.id).fadeIn();
                    });
                    $('.third-level li a').mouseover(function () {
                        if (this.id) {
                            $(".fourth-level").hide();
                            $(".fifth-level").hide();
                        }
                        $('.fourth-level').hide().filter('#box' + this.id).fadeIn();
                    });
                    $('.fourth-level li a').mouseover(function () {
                        if (this.id) {
                            // $(".fifth-level").hide();
                        }
                        $('.fifth-level').hide().filter('#box' + this.id).fadeIn();
                    });

                    $('.main-header .nav-link').hover(function () {
                        $(this).toggleClass('fw-bold')
                    })
                });
            }
        });
        // DOMContentLoaded  end
        $("#btn-cerca").click(function() {
            $("#cerca").focus();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.selectpicker').selectpicker();
        })
    </script>
</body>
</html>
